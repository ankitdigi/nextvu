<!DOCTYPE html>
<html class="js">
	<head>
		<title>Interpreting nextlab</title>
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
		<style>
		@page {margin:0mm;}
		body{margin: 0px;}
		*{font-family:'Open Sans',sans-serif}
		table th{text-align: left; font-weight: 400;}
		.filled-checkbox{display: none;}
		</style>
	</head>
	<body bgcolor="#fff">
		<table class="main_container" width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
			<tbody>
				<tr>
					<td width="100%">
						<table class="header" cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
							<tbody>
								<tr>
									<td width="100%">
										<table width="100%" cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>
													<td align="left" valign="middle" style="background:#426e89; padding: 5mm 0mm 5mm 8mm;">
														<p style="font-size: 32px;text-transform: uppercase;color: #ffffff;font-weight: 400; margin: 0; letter-spacing: 2px; line-height: 38px; white-space:nowrap;">Serum test<br> Request form</p>
													</td>
													<td valign="top"><img src="<?php echo base_url("/assets/images/aqua-corner-shape.png"); ?>" alt="NextVu" height="180" /></td>
													<td width="7%">&nbsp;</td>
													<td align="right" style="padding: 0 8mm 0 0;">
														<img src="<?php echo base_url("/assets/images/nextmune-uk.png"); ?>" height="55" alt="NextVu" />
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding: 8mm 8mm 2mm;">
			<tbody>
				<tr>
					<td width="100%">
						<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
							<tbody>
								<tr>
									<td width="100%">
										<table cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>
													<td style="color:#426e89; letter-spacing:1px; font-size:20px;">Practice details</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="padding: 0mm 8mm;">
			<tr>
				<td width="49%" valign="top">
					<table width="100%" cellspacing="0" cellpadding="0" border="0">
						<tbody>
							<tr>
								<td width="100%">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td width="33%" valign="middle">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tbody>
															<tr>
																<td width="100%" valign="top">
																	<p style="color:#1c3642; font-size:13px; line-height: 22px;">Date:</p>
																</td>
															</tr>
															<tr>
																<td style="height: 5px; line-height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 25px; padding:0 10px; font-size:13px;"></td>
															</tr>
														</tbody>
													</table>
												</td>
												<td width="2%">&nbsp;</td>
												<td width="65%" valign="middle">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tbody>
															<tr>
																<td width="100%" valign="top">
																	<p style="color:#1c3642; font-size:13px; line-height: 22px;">Veterinary surgeon:</p>
																</td>
															</tr>
															<tr>
																<td style="height: 5px; line-height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 25px; padding:0 10px; font-size:13px;"></td>
															</tr>
														</tbody>
													</table>
												</td>
											</tr>
											<tr>
												<td style="height:5px; line-height:5px;"></td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td width="100%" valign="middle">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td width="100%" valign="top">
													<p style="color:#1c3642; font-size:13px; line-height: 22px;">Veterinary practice:</p>
												</td>
											</tr>
											<tr>
												<td style="height:5px; line-height:5px;"></td>
											</tr>
											<tr>
												<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 25px; padding:0 10px; font-size:13px;"></td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td style="height:5px; line-height:5px;"></td>
							</tr>
							<tr>
								<td width="100%" valign="middle">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td width="100%" valign="top">
													<p style="color:#1c3642; font-size:13px; line-height: 22px;">Practice details:</p>
												</td>
											</tr>
											<tr>
												<td style="height: 5px; line-height: 5px;"></td>
											</tr>
											<tr>
												<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 25px; padding:0 10px; font-size:13px;"></td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td style="height:5px; line-height:5px;"></td>
							</tr>
							<tr>
								<td width="100%">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td width="63%" valign="middle">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tbody>
															<tr>
																<td width="100%" valign="top">
																	<p style="color:#1c3642; font-size:13px; line-height: 22px;">City:</p>
																</td>
															</tr>
															<tr>
																<td style="height: 5px; line-height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 25px; padding:0 10px; font-size:13px;"></td>
															</tr>
														</tbody>
													</table>
												</td>
												<td width="2%">&nbsp;</td>
												<td width="35%" valign="middle">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tbody>
															<tr>
																<td width="100%" valign="top">
																	<p style="color:#1c3642; font-size:13px; line-height: 22px;">Postcode:</p>
																</td>
															</tr>
															<tr>
																<td style="height: 5px; line-height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 25px; padding:0 10px; font-size:13px;"></td>
															</tr>
														</tbody>
													</table>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td width="2%">&nbsp;</td>
				<td width="49%" valign="top">
					<table width="100%" cellspacing="0" cellpadding="0" border="0">
						<tbody>
							<tr>
								<td width="100%" valign="middle">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td width="100%" valign="top">
													<p style="color:#1c3642; font-size:13px; line-height: 22px;">Phone:</p>
												</td>
											</tr>
											<tr>
												<td style="height:5px; line-height:5px;"></td>
											</tr>
											<tr>
												<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 25px; padding:0 10px; font-size:13px;"></td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td style="height:5px; line-height:5px;"></td>
							</tr>
							<tr>
								<td width="100%" valign="middle">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td width="100%" valign="top">
													<p style="color:#1c3642; font-size:13px; line-height: 22px;">Email:</p>
												</td>
											</tr>
											<tr>
												<td style="height: 5px; line-height: 5px;"></td>
											</tr>
											<tr>
												<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 25px; padding:0 10px; font-size:13px;"></td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td style="height:5px; line-height:5px;"></td>
							</tr>
							<tr>
								<td width="100%" valign="middle">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td width="100%" valign="top">
													<p style="color:#1c3642; font-size:13px; line-height: 22px;">Results will be delivered by email.</p>
												</td>
											</tr>
											<tr>
												<td style="height: 5px; line-height: 5px;"></td>
											</tr>
											<tr>
												<td width="100%">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tbody>
															<tr>
																<td width="4%" valign="middle">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tbody>
																			<tr>
																				<td>
																					<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																					<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																				</td>
																			</tr>
																		</tbody>
																	</table>
																</td>
																<td width="2%">&nbsp;</td>
																<td width="94%" valign="middle">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tbody>
																			<tr>
																				<td style="color:#1c3642; font-size:12px;">
																					I would like to order more serum test shipping materials
																				</td>
																			</tr>
																		</tbody>
																	</table>
																</td>
															</tr>
														</tbody>
													</table>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
			</tr>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
			<tbody>
				<tr>
					<td style="height: 25px;"></td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="padding: 0 8mm">
			<tbody>
				<tr>
					<td width="100%">
						<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
							<tbody>
								<tr>
									<td width="100%">
										<table cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>
													<td style="color:#426e89; letter-spacing:1px; font-size:20px;">Animal and owner details</td>
												</tr>
												<tr>
													<td style="height: 10px; line-height: 10px;"></td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="padding: 0mm 8mm;">
			<tr>
				<td width="49%" valign="top">
					<table width="100%" cellspacing="0" cellpadding="0" border="0">
						<tbody>
							<tr>
								<td width="100%">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td width="33%" valign="middle">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tbody>
															<tr>
																<td width="100%" valign="middle">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td valign="middle" width="18%">
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																			</td>
																			<td valign="middle" width="82%" style="color:#1c3642; font-size:12px; line-height: 20px;">Dog</td>
																		</tr>
																	</table>
																</td>
															</tr>
														</tbody>
													</table>
												</td>
												<td width="33%" valign="middle">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tbody>
															<tr>
																<td width="100%" valign="middle">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td valign="middle" width="18%">
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																			</td>
																			<td valign="middle" width="82%" style="color:#1c3642; font-size:12px; line-height: 20px;">Cat</td>
																		</tr>
																	</table>
																</td>
															</tr>
														</tbody>
													</table>
												</td>
												<td width="33%" valign="middle">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tbody>
															<tr>
																<td width="100%" valign="middle">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td valign="middle" width="18%">
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																			</td>
																			<td valign="middle" width="82%" style="color:#1c3642; font-size:12px; line-height: 20px;">Horse</td>
																		</tr>
																	</table>
																</td>
															</tr>
														</tbody>
													</table>
												</td>
											</tr>
											<tr>
												<td width="33%" valign="middle">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tbody>
															<tr>
																<td width="100%" valign="middle">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td valign="middle" width="18%">
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																			</td>
																			<td valign="middle" width="82%" style="color:#1c3642; font-size:12px; line-height: 20px;">Male</td>
																		</tr>
																	</table>
																</td>
															</tr>
														</tbody>
													</table>
												</td>
												<td width="33%" valign="middle">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tbody>
															<tr>
																<td width="100%" valign="middle">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td valign="middle" width="18%">
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																			</td>
																			<td valign="middle" width="82%" style="color:#1c3642; font-size:12px; line-height: 20px;">Female</td>
																		</tr>
																	</table>
																</td>
															</tr>
														</tbody>
													</table>
												</td>
												<td width="33%" valign="middle"></td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td style="height:10px"></td>
							</tr>
							<tr>
								<td width="100%" valign="middle">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td width="100%" valign="top">
													<p style="color:#1c3642; font-size:13px; line-height: 22px;">Owner name:</p>
												</td>
											</tr>
											<tr>
												<td style="height:5px; line-height:5px;"></td>
											</tr>
											<tr>
												<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 25px; padding:0 10px; font-size:13px;"></td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td width="100%" valign="middle">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td style="height:10px;"></td>
											</tr>
											<tr>
												<td width="100%" valign="top">
													<p style="color:#1c3642; font-size:13px; line-height: 22px;">Animal name:</p>
												</td>
											</tr>
											<tr>
												<td style="height:5px; line-height:5px;"></td>
											</tr>
											<tr>
												<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 25px; padding:0 10px; font-size:13px;"></td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td width="100%" valign="middle">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td style="height:10px;"></td>
											</tr>
											<tr>
												<td width="100%" valign="top">
													<p style="color:#1c3642; font-size:13px; line-height: 22px;">Breed:</p>
												</td>
											</tr>
											<tr>
												<td style="height:5px; line-height:5px;"></td>
											</tr>
											<tr>
												<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 25px; padding:0 10px; font-size:13px;"></td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td width="100%">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td style="height:10px;"></td>
											</tr>
											<tr>
												<td width="57%" valign="middle">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tbody>
															<tr>
																<td width="100%" valign="top">
																	<p style="color:#1c3642; font-size:13px; line-height: 22px;">Date of birth:</p>
																</td>
															</tr>
															<tr>
																<td style="height: 5px; line-height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 25px; padding:0 10px; font-size:13px;"></td>
															</tr>
														</tbody>
													</table>
												</td>
												<td width="2%">&nbsp;</td>
												<td width="40%" valign="middle">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tbody>
															<tr>
																<td width="100%" valign="top">
																	<p style="color:#1c3642; font-size:13px; line-height: 22px;">Date serum drawn:</p>
																</td>
															</tr>
															<tr>
																<td style="height: 5px; line-height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 25px; padding:0 10px; font-size:13px;"></td>
															</tr>
														</tbody>
													</table>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td width="100%" style="height: 10px;"></td>
							</tr>
							<tr>
								<td width="100%">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td width="100%" valign="middle">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tr>
															<td width="100%" style="color:#1c3642; font-size:13px; line-height: 22px;">
																Is this animal suffering from a zoonotic disease?
															</td>
														</tr>
													</table>
												</td>
											</tr>
											<tr>
												<td width="100%">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tr>
															<td width="100%">
																<table width="100%" cellspacing="0" cellpadding="0" border="0">
																	<tr>
																		<td width="33%" valign="middle">
																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																				<tbody>
																					<tr>
																						<td width="100%" valign="middle">
																							<table width="100%" cellspacing="0" cellpadding="0" border="0">
																								<tr>
																									<td valign="middle" width="18%">
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																									</td>
																									<td valign="middle" width="82%" style="color:#1c3642; font-size:13px; line-height: 22px;">Yes</td>
																								</tr>
																							</table>
																						</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																		<td width="33%">
																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																				<tbody>
																					<tr>
																						<td width="100%" valign="middle">
																							<table width="100%" cellspacing="0" cellpadding="0" border="0">
																								<tr>
																									<td valign="middle" width="18%">
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																									</td>
																									<td valign="middle" width="82%" style="color:#1c3642; font-size:13px; line-height: 22px;">No</td>
																								</tr>
																							</table>
																						</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																		<td width="33%" valign="middle"></td>
																	</tr>
																</table>
															</td>
														</tr>
														<tr>
															<td width="100%" style="height: 5px;">
																
															</td>
														</tr>
														<tr>
															<td width="100%" valign="middle">
																<table width="100%" cellspacing="0" cellpadding="0" border="0">
																	<tbody>
																		<tr>
																			<td width="100%" valign="top">
																				<p style="color:#1c3642; font-size:13px; line-height: 22px;">If yes, please specify:</p>
																			</td>
																		</tr>
																		<tr>
																			<td style="height:5px; line-height:5px;"></td>
																		</tr>
																		<tr>
																			<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 75px; padding:0 10px; font-size:13px;"></td>
																		</tr>
																	</tbody>
																</table>
															</td>
														</tr>
													</table>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td width="2%">&nbsp;</td>
				<td width="49%" valign="top">
					<table width="100%" cellspacing="0" cellpadding="0" border="0">
						<tbody>
							<tr>
								<td width="100%">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td width="100%" valign="middle">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tr>
															<td width="100%" style="color:#1c3642; font-size:13px; line-height: 22px;">
																What are the major presenting symptoms?
															</td>
														</tr>
													</table>
												</td>
											</tr>
											<tr>
												<td width="100%">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tr>
															<td width="100%">
																<table width="100%" cellspacing="0" cellpadding="0" border="0">
																	<tr>
																		<td width="20%" valign="middle">
																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																				<tbody>
																					<tr>
																						<td width="100%" valign="middle">
																							<table width="100%" cellspacing="0" cellpadding="0" border="0">
																								<tr>
																									<td valign="middle" width="20%">
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																									</td>
																									<td valign="middle" width="75%" style="color:#1c3642; font-size:12px; line-height: 20px;">Pruritus</td>
																								</tr>
																							</table>
																						</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																		<td width="17%">
																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																				<tbody>
																					<tr>
																						<td width="100%" valign="middle">
																							<table width="100%" cellspacing="0" cellpadding="0" border="0">
																								<tr>
																									<td valign="middle" valign="middle" width="30%">
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																									</td>
																									<td valign="middle" valign="middle" width="70%" style="color:#1c3642; font-size:12px; line-height: 20px;">Otitis</td>
																								</tr>
																							</table>
																						</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																		<td width="27%">
																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																				<tbody>
																					<tr>
																						<td width="100%" valign="middle">
																							<table width="100%" cellspacing="0" cellpadding="0" border="0">
																								<tr>
																									<td valign="middle" width="18%">
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																									</td>
																									<td valign="middle" width="77%" style="color:#1c3642; font-size:12px; line-height: 20px;">Respiratory</td>
																								</tr>
																							</table>
																						</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																		<td width="36%">
																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																				<tbody>
																					<tr>
																						<td width="100%" valign="middle">
																							<table width="100%" cellspacing="0" cellpadding="0" border="0">
																								<tr>
																									<td valign="middle" width="15%">
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																									</td>
																									<td valign="middle" width="82%" style="color:#1c3642; font-size:12px; line-height: 20px;">Gastrointestinal</td>
																								</tr>
																							</table>
																						</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																	</tr>
																</table>
															</td>
														</tr>
														<tr>
															<td width="100%" style="height: 5px;"></td>
														</tr>
														<tr>
															<td width="100%" valign="middle">
																<table width="100%" cellspacing="0" cellpadding="0" border="0">
																	<tbody>
																		<tr>
																			<td width="25%" valign="middle">
																				<table width="100%" cellspacing="0" cellpadding="0" border="0">
																					<tbody>
																						<tr>
																							<td width="100%" valign="middle">
																								<table width="100%" cellspacing="0" cellpadding="0" border="0">
																									<tr>
																										<td valign="middle" width="20%">
																											<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																											<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																										</td>
																										<td valign="middle" width="75%" style="color:#1c3642; font-size:12px; line-height: 20px;">Other</td>
																									</tr>
																								</table>
																							</td>
																						</tr>
																					</tbody>
																				</table>
																			</td>
																			<td width="75%">
																				<table width="100%" cellspacing="0" cellpadding="0" border="0">
																					<tbody>
																						<tr>
																							<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 25px; padding:0 10px; font-size:13px;"></td>
																						</tr>
																					</tbody>
																				</table>
																			</td>
																		</tr>
																	</tbody>
																</table>
															</td>
														</tr>
													</table>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td style="height:10px"></td>
							</tr>
							<tr>
								<td width="100%" valign="middle">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td style="height: 10px;"></td>
											</tr>
											<tr>
												<td width="100%" valign="top">
													<p style="color:#1c3642; font-size:13px; line-height: 22px;">At what age did these symptoms first appear?:</p>
												</td>
											</tr>
											<tr>
												<td style="height:5px; line-height:5px;"></td>
											</tr>
											<tr>
												<td width="100%">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tr>
															<td width="60%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 25px; padding:0 10px; font-size:13px;"></td>
															<td width="40%">&nbsp;</td>
														</tr>
													</table>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td style="height:10px"></td>
							</tr>
							<tr>
								<td width="100%">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td style="height: 10px;"></td>
											</tr>
											<tr>
												<td width="100%" valign="middle">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tr>
															<td width="100%" style="color:#1c3642; font-size:13px; line-height: 22px;">
																When are the symptoms most obvious?
															</td>
														</tr>
													</table>
												</td>
											</tr>
											<tr>
												<td width="100%">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tr>
															<td width="100%">
																<table width="100%" cellspacing="0" cellpadding="0" border="0">
																	<tr>
																		<td width="20%" valign="middle">
																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																				<tbody>
																					<tr>
																						<td width="100%" valign="middle">
																							<table width="100%" cellspacing="0" cellpadding="0" border="0">
																								<tr>
																									<td valign="middle" width="20%">
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																									</td>
																									<td valign="middle" width="75%" style="color:#1c3642; font-size:12px; line-height: 20px;">Spring</td>
																								</tr>
																							</table>
																						</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																		<td width="20%" valign="middle">
																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																				<tbody>
																					<tr>
																						<td width="100%" valign="middle">
																							<table width="100%" cellspacing="0" cellpadding="0" border="0">
																								<tr>
																									<td valign="middle" width="20%">
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																									</td>
																									<td valign="middle" width="75%" style="color:#1c3642; font-size:12px; line-height: 20px;">Summer</td>
																								</tr>
																							</table>
																						</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																		<td width="20%" valign="middle">
																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																				<tbody>
																					<tr>
																						<td width="100%" valign="middle">
																							<table width="100%" cellspacing="0" cellpadding="0" border="0">
																								<tr>
																									<td valign="middle" width="20%">
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																									</td>
																									<td valign="middle" width="75%" style="color:#1c3642; font-size:12px; line-height: 20px;">Autumn</td>
																								</tr>
																							</table>
																						</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																		<td width="20%" valign="middle">
																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																				<tbody>
																					<tr>
																						<td width="100%" valign="middle">
																							<table width="100%" cellspacing="0" cellpadding="0" border="0">
																								<tr>
																									<td valign="middle" width="20%">
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																									</td>
																									<td valign="middle" width="75%" style="color:#1c3642; font-size:12px; line-height: 20px;">Winter</td>
																								</tr>
																							</table>
																						</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																		<td width="20%" valign="middle">
																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																				<tbody>
																					<tr>
																						<td width="100%" valign="middle">
																							<table width="100%" cellspacing="0" cellpadding="0" border="0">
																								<tr>
																									<td valign="middle" width="20%">
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																									</td>
																									<td valign="middle" width="75%" style="color:#1c3642; font-size:12px; line-height: 20px;">All year</td>
																								</tr>
																							</table>
																						</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																	</tr>
																</table>
															</td>
														</tr>
													</table>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td style="height:10px"></td>
							</tr>
							<tr>
								<td width="100%">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td style="height: 10px;"></td>
											</tr>
											<tr>
												<td width="100%" valign="middle">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tr>
															<td width="100%" style="color:#1c3642; font-size:13px; line-height: 22px;">
																Where are the symptoms most obvious?
															</td>
														</tr>
													</table>
												</td>
											</tr>
											<tr>
												<td width="100%">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tr>
															<td width="100%">
																<table width="100%" cellspacing="0" cellpadding="0" border="0">
																	<tr>
																		<td width="33%" valign="middle">
																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																				<tbody>
																					<tr>
																						<td width="100%" valign="middle">
																							<table width="100%" cellspacing="0" cellpadding="0" border="0">
																								<tr>
																									<td valign="middle" width="20%">
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																									</td>
																									<td valign="middle" width="75%" style="color:#1c3642; font-size:12px; line-height: 20px;">Indoors</td>
																								</tr>
																							</table>
																						</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																		<td width="33%" valign="middle">
																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																				<tbody>
																					<tr>
																						<td width="100%" valign="middle">
																							<table width="100%" cellspacing="0" cellpadding="0" border="0">
																								<tr>
																									<td valign="middle" width="20%">
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																									</td>
																									<td valign="middle" width="75%" style="color:#1c3642; font-size:12px; line-height: 20px;">Outdoors</td>
																								</tr>
																							</table>
																						</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																		<td width="33%" valign="middle">
																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																				<tbody>
																					<tr>
																						<td width="100%" valign="middle">
																							<table width="100%" cellspacing="0" cellpadding="0" border="0">
																								<tr>
																									<td valign="middle" width="20%">
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																									</td>
																									<td valign="middle" width="75%" style="color:#1c3642; font-size:12px; line-height: 20px;">No difference</td>
																								</tr>
																							</table>
																						</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																	</tr>
																</table>
															</td>
														</tr>
													</table>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td style="height: 10px;"></td>
							</tr>
							<tr>
								<td width="100%">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td width="100%" valign="middle">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tr>
															<td width="100%" style="color:#1c3642; font-size:13px; line-height: 22px;">
																Is the animal receiving any medication at the moment?
															</td>
														</tr>
													</table>
												</td>
											</tr>
											<tr>
												<td width="100%">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tr>
															<td width="100%">
																<table width="100%" cellspacing="0" cellpadding="0" border="0">
																	<tr>
																		<td width="33%" valign="middle">
																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																				<tbody>
																					<tr>
																						<td width="100%" valign="middle">
																							<table width="100%" cellspacing="0" cellpadding="0" border="0">
																								<tr>
																									<td width="18%">
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																									</td>
																									<td width="82%" style="color:#1c3642; font-size:13px; line-height: 22px;">Yes</td>
																								</tr>
																							</table>
																						</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																		<td width="33%">
																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																				<tbody>
																					<tr>
																						<td width="100%" valign="middle">
																							<table width="100%" cellspacing="0" cellpadding="0" border="0">
																								<tr>
																									<td width="18%">
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																									</td>
																									<td width="82%" style="color:#1c3642; font-size:13px; line-height: 22px;">No</td>
																								</tr>
																							</table>
																						</td>
																					</tr>
																				</tbody>
																			</table>
																		</td>
																		<td width="33%" valign="middle"></td>
																	</tr>
																</table>
															</td>
														</tr>
														<tr>
															<td width="100%" style="height: 5px;"></td>
														</tr>
														<tr>
															<td width="100%" valign="middle">
																<table width="100%" cellspacing="0" cellpadding="0" border="0">
																	<tbody>
																		<tr>
																			<td width="100%" valign="top">
																				<p style="color:#1c3642; font-size:13px; line-height: 22px;">If yes, please specify:</p>
																			</td>
																		</tr>
																		<tr>
																			<td style="height:5px; line-height:5px;"></td>
																		</tr>
																		<tr>
																			<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 75px; padding:0 10px; font-size:13px;"></td>
																		</tr>
																	</tbody>
																</table>
															</td>
														</tr>
													</table>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
			</tr>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
			<tbody>
				<tr>
					<td style="height: 25px;"></td>
				</tr>
			</tbody>
		</table>
		<table width="100%" cellspacing="0" cellpadding="0" border="0">
			<tr>
				<td width="80%" valign="top">
					<table width="100%" cellspacing="0" cellpadding="0" border="0">
						<tr>
							<td width="100%" valign="middle">
								<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding: 0mm 8mm;">
									<tbody>
										<tr>
											<td width="100%" valign="top">
												<p style="color:#1c3642; font-size:13px; line-height: 22px;">Internal Use Only</p>
											</td>
										</tr>
										<tr>
											<td style="height:5px; line-height:5px;"></td>
										</tr>
										<tr>
											<td width="100%" style="background:#fff; border:1px solid #5b8398; outline:none; height: 75px; padding:0 10px; font-size:13px;"></td>
										</tr>
									</tbody>
								</table>
							</td>
						</tr>
						<tr>
							<td style="height: 20px;"></td>
						</tr>
						<tr>
							<td width="100%" valign="middle">
								<table width="100%" cellspacing="0" cellpadding="0" border="0" style="background-color: #e5f4f7;">
									<tbody>
										<tr>
											<td width="100%" style="padding: 2.5mm 0 2.5mm 8mm;">
												<p style="color:#426e89; font-size:15px; line-height: 22px;">For allergy resources visit nextmunelaboratories.co.uk/login</p>
											</td>
										</tr>
									</tbody>
								</table>
							</td>
						</tr>
					</table>
				</td>
				<td width="20%" valign="bottom">
					<table width="100%" cellspacing="0" cellpadding="0" border="0">
						<tr>
							<td width="100%">
								<img src="assets/images/practice-portal-lock-img.png" width="215">
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
		<table width="100%" cellspacing="0" cellpadding="0" border="0" align="center" style="background-color: #426e89;">
			<tbody>
				<tr>
					<td width="100%">
						<table class="header" cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
							<tbody>
								<tr>
									<td width="100%" style="height: 25px;"></td>
								</tr>
								<tr>
									<td width="100%" align="center" valign="middle">
										<table width="100%" cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>
													<td>
														<p style="font-size: 26px;color: #fff;font-weight: 400; margin: 0; text-transform: uppercase; text-align: center;">Sample Submission Form</p>
													</td>
											</tr></tbody>
										</table>
									</td>
								</tr>
								<tr>
									<td width="100%" style="height: 5px; line-height: 5px;"></td>
								</tr>
								<tr>
									<td width="100%" align="center" valign="middle">
										<table cellpadding="0" cellspacing="0" border="0" width="100%">
											<tbody>
												<tr>
													<td>
														<p style="font-size: 16px;color: #fff;font-weight: 400; margin: 0; text-transform: uppercase; text-align:center;">Please select individual test(s) by ticking the appropriate box(es)</p>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
								<tr>
									<td width="100%" style="height: 10px;"></td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table width="100%" cellspacing="0" cellpadding="0" border="0" align="center" style="padding: 0 12mm;">
			<tbody>
				<tr>
					<td width="100%" style="height: 20px; line-height: 20px;"></td>
				</tr>
				<tr>
					<td width="100%">
						<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
							<tbody>
								<tr>
									<td width="25%" align="left" valign="top">
										<table width="100%" cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>
													<td>
														<p style="font-size: 20px;color: #426e89;font-weight: 600; margin: 0; text-transform: uppercase;">STORAGE ONLY</p>
													</td>
											</tr></tbody>
										</table>
									</td>
									<td width="75%" align="left" valign="top">
										<table cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td width="100%">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tbody>
																				<tr>
																					<td width="5%" valign="top">
																						<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																						<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																					</td>
																					<td valign="top" width="95%" style="color:#000; font-size:13px; text-align: left;">
																						Samples will be held free of charge for 3 months. If you select storage only, please do not tick a test type. Please contact us when you wish to run this sample.
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
				<tr>
					<td width="100%" style="height: 10px;"></td>
				</tr>
			</tbody>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding: 0 8mm 0 0;">
			<tbody>
				<tr>
					<td width="100%">
						<table width="100%" cellspacing="0" cellpadding="0" border="0">
							<tbody>
								<tr>
									<td width="25%" align="left" valign="top">
										<img src="<?php echo base_url("/assets/images/dog.png"); ?>" width="200" alt="CANINE TEST" />
									</td>
									<td width="75%" align="left" valign="top">
										<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:17px 0 0 0;">
											<tbody>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="50%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td style="background:#cee8ee; color:#426e89; font-size:24px; text-transform: uppercase;">Canine Tests</td>
																			<td style="line-height:0;" valign="top"><img src="<?php echo base_url("/assets/images/tail1.png"); ?>"  height="51" alt="CANINE" /></td>
																		</tr>
																	</table>
																</td>
																<td width="50%">&nbsp;</td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="height: 10px;"></td>
															</tr>
															<tr>
																<td width="100%" style="text-transform: uppercase; font-size: 16px; color:#426e89;"><b>Nextlab</b></td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td valign="top" width="5%">
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">COMPLETE ENVIRONMENTAL & FOOD : Food panel, environmental panel (indoor & outdoor) & Malassezia IgE. Sample required: 2ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																		<tr>
																			<td valign="top" width="5%">
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">ENVIRONMENTAL: Environmental panel (indoor & outdoor) & Malassezia IgE. Sample required: 1ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																		<tr>
																			<td valign="top" width="5%">
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">FOOD : Food panel. Sample required: 1ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																	</table>
																</td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="font-size: 11px; color:#000;"><b style="text-transform: uppercase; font-size: 16px; color:#426e89;">Nextlab Screens</b><b>(positive/negative result only; can be expanded on request)</b></td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td valign="top" width="5%">
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">ENVIRONMENTAL SCREEN: Sample required: 1ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																		<tr>
																			<td valign="top" width="5%">
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">FOOD SCREEN: Sample required: 1ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																	</table>
																</td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%"><b style="text-transform: uppercase; font-size: 16px; color:#426e89;">ACUTE PHASE PROTEINS (APPs)</b></td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td valign="top" width="5%">
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">C-REACTIVE PROTEIN (CRP) Sample required: 0.5ml serum</td>
																		</tr>
																	</table>
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding: 0 8mm 0 0;">
			<tbody>
				<tr>
					<td width="100%" style="height: 5px;"></td>
				</tr>
				<tr>
					<td width="100%">
						<table width="100%" cellspacing="0" cellpadding="0" border="0">
							<tbody>
								<tr>
									<td width="25%" align="left" valign="top">
										<img src="<?php echo base_url("/assets/images/cat.png"); ?>" width="200" alt="Feline TEST" />
									</td>
									<td width="75%" align="left" valign="top">
										<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:27px 0 0 0;">
											<tbody>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="50%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td style="background:#7dc1c9; color:#fff; font-size:24px; text-transform: uppercase;">Feline Tests</td>
																			<td style="line-height:0;" valign="top"><img src="<?php echo base_url("/assets/images/tail2.png"); ?>"  height="51" alt="Feline" /></td>
																		</tr>
																	</table>
																</td>
																<td width="50%">&nbsp;</td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="height: 10px;"></td>
															</tr>
															<tr>
																<td width="100%" style="text-transform: uppercase; font-size: 16px; color:#426e89;"><b>Nextlab</b></td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td valign="top" width="5%">
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">COMPLETE ENVIRONMENTAL & FOOD: Food panel, environmental panel (indoor & outdoor). Sample required: 2ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																		<tr>
																			<td valign="top" width="5%">
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">ENVIRONMENTAL: Environmental panel (indoor & outdoor). Sample required: 1ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																		<tr>
																			<td valign="top" width="5%">
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">FOOD : Food panel. Sample required: 1ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																	</table>
																</td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="font-size: 11px; color:#000;"><b style="text-transform: uppercase; font-size: 16px; color:#426e89;">Nextlab Screens</b><b>(positive/negative result only; can be expanded on request)</b></td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td valign="top" width="5%">
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">ENVIRONMENTAL SCREEN: Sample required: 1ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																		<tr>
																			<td valign="top" width="5%">
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">FOOD SCREEN: Sample required: 1ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																	</table>
																</td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%"><b style="text-transform: uppercase; font-size: 16px; color:#426e89;">ACUTE PHASE PROTEINS (APPs)</b></td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td valign="top" width="5%">
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">α1-ACID GLYCOPROTEIN (AGP): Sample required: 0.5ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																	</table>
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding: 0 8mm 0 0;">
			<tbody>
				<tr>
					<td width="100%">
						<table width="100%" cellspacing="0" cellpadding="0" border="0">
							<tbody>
								<tr>
									<td width="25%" align="left" valign="top">
										<img src="<?php echo base_url("/assets/images/horse.png"); ?>" width="200" alt="Equine TEST" />
									</td>
									<td width="75%" align="left" valign="top">
										<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:17px 0 0 0;">
											<tbody>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="50%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td style="background:#b8c6d6; color:#426e89; font-size:24px; text-transform: uppercase;">Equine Tests</td>
																			<td style="line-height:0;" valign="top"><img src="<?php echo base_url("/assets/images/tail3.png"); ?>"  height="51" alt="Equine" /></td>
																		</tr>
																	</table>
																</td>
																<td width="50%">&nbsp;</td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="height: 10px;"></td>
															</tr>
															<tr>
																<td width="100%" style="text-transform: uppercase; font-size: 16px; color:#426e89;"><b>Nextlab</b></td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td valign="top" width="5%">
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																			</td>
																			<td valign="top" width="95%" style="font-size: 12px; line-height: 16px; color:#000;">COMPLETE ENVIRONMENTAL, INSECT & FOOD: Food panel, environmental panel (indoor & outdoor) and insect panel. Sample required: 3ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																		<tr>
																			<td valign="top" width="5%">
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																			</td>
																			<td valign="top" width="95%" style="font-size: 12px; line-height: 16px; color:#000;">ENVIRONMENTAL & INSECT: Environmental panel (indoor & outdoor) & insect panel. Sample required: 2ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																		<tr>
																			<td valign="top" width="5%">
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																			</td>
																			<td valign="top" width="95%" style="font-size: 12px; line-height: 16px; color:#000;">FOOD: Food panel. Sample required: 1ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																	</table>
																</td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="font-size: 11px; color:#000;"><b style="text-transform: uppercase; font-size: 16px; color:#426e89;">Nextlab Screens</b><b>(positive/negative result only; can be expanded on request)</b></td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td valign="top" width="5%">
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																			</td>
																			<td valign="top" width="95%" style="font-size: 12px; line-height: 16px; color:#000;">ENVIRONMENTAL & INSECT SCREEN: Sample required: 2ml serum</td>
																		</tr>
																	</table>
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding: 0 8mm;">
			<tr>
				<td width="100%">
					<table width="100%" cellspacing="0" cellpadding="0" border="0">
						<tr>
							<td width="100%" style="height: 10px;"></td>
						</tr>
						<tr>
							<td width="100%" style="font-size: 10px; line-height: 15px; color: #000;">
								Samples submitted are subject to Nextmune Laboratories’ terms & conditions of business (www.nextmunelaboratories.co.uk/terms-of-business)
							</td>
						</tr>
						<tr>
							<td width="100%" style="height: 5px;"></td>
						</tr>
						<tr>
							<td width="100%" style="font-size: 10px; line-height: 15px; color: #000;">
								We may store and use any surplus serum for quality control, research and development purposes.
							</td>
						</tr>
						<tr>
							<td width="100%">
								<table width="100%" cellspacing="0" cellpadding="0" border="0">
									<tr>
										<td width="60%">
											<table width="100%" cellspacing="0" cellpadding="0" border="0">
												<tr>
													<td width="85%" style="font-size: 10px; line-height: 15px; color: #000;">
														If you do not wish Nextmune Laboratories to utilise this sample, please tick here
													</td>
													<td width="15%">
														<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" width="8"/>
														<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" width="8"/>
													</td>
												</tr>
											</table>
										</td>
										<td width="40%"></td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td width="100%" style="height: 10px;"></td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
		<table width="100%" cellspacing="0" cellpadding="0" border="0" style="background-color: #426e89; padding: 1.5mm 0;">
			<tr>
				<td width="100%" align="center">
					<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding: 0 8mm;">
						<tr>
							<td width="100%">
								<table width="100%" cellspacing="0" cellpadding="0" border="0">
									<tr>
										<td width="100%" style="font-size: 12px; line-height: 20px; color: #fff;">
											Nextmune Laboratories Limited, Unit 651, Street 5, Thorp Arch Trading Estate, Wetherby, UK, LS23 7FZ
										</td>
									</tr>
									<tr>
										<td width="100%">
											<table width="100%" cellspacing="0" cellpadding="0" border="0">
												<tr>
													<td width="49%" style="font-size: 12px; line-height: 20px; color: #fff; text-align: right;">
														T – 0800 3 047 047
													</td>
													<td width="2%">&nbsp;</td>
													<td width="49%" style="font-size: 12px; line-height: 20px; color: #fff; text-align: left;">
														E – <a href="mailto:vetorders.uk@nextmune.com" style="color: #fff; text-decoration: none;">vetorders.uk@nextmune.com</a>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
		<table width="100%" cellspacing="0" cellpadding="0" border="0">
			<tr>
				<td width="100%" style="height: 5px;"></td>
			</tr>
		</table>
		<table width="100%" cellspacing="0" cellpadding="0" border="0">
			<tr>
				<td width="100%" align="center">
					<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding: 0 8mm;">
						<tr>
							<td width="100%">
								<table width="100%" cellspacing="0" cellpadding="0" border="0">
									<tr>
										<td width="49%" style="font-size: 8px; line-height: 20px; color: #000; text-align: left;">
											<b>© 2022 Nextmune Laboratories Limited</b>
										</td>
										<td width="2%">&nbsp;</td>
										<td width="49%" style="font-size: 8px; line-height: 20px; color: #000; text-align: right;">
											NM035_06_22
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</body>
</html>