<table width="100%"><tr><td height="20"></td></tr></table>
<table class="main_container" cellspacing="0" cellpadding="0" border="0" align="center" style="width:100%;max-width:100%;background:url(<?php echo base_url(); ?>assets/images/pax-bg.png) center top no-repeat #ffffff;background-size:100%;padding:5px;">
	<tr>
		<td style="padding: 5px;">
			<table width="100%" cellspacing="0" cellpadding="0" border="0" align="center" style="">
				<tr>
					<th valign="bottom" align="left" style="padding:0 0 5px 0; border-bottom:2px solid #3a6a86; font-weight:400;"><img src="<?php echo base_url(); ?>assets/images/pax-logo.png" alt="" style="max-height:40px;"></th>
					<th valign="bottom" style="padding:0 0 5px 0; border-bottom:2px solid #3a6a86; font-weight:400;"><b><?php echo $order_details['pet_name']; ?></b><?php echo $order_details['pet_owner_name'].' '.$order_details['po_last']; ?></th>
					<th valign="bottom" style="padding:0 0 5px 0; border-bottom:2px solid #3a6a86; font-weight:400;"><b><?php echo $this->lang->line('customer'); ?>:</b> <?php echo $order_details['order_number']; ?></th>
					<th valign="bottom" style="padding:0 0 5px 0; border-bottom:2px solid #3a6a86; font-weight:400;"><b><?php echo $this->lang->line('test'); ?>:</b> <?php echo $raptorData->sample_code; ?></th>
				</tr>
			</table>
			<table width="100%"><tr><td height="20"></td></tr></table>

			<table width="100%" cellspacing="0" cellpadding="0" border="0" align="center" style="">
				<tr>
					<td>
						<h4 style="margin:0; color:#2a5b74; font-size:24px;"><?php echo $this->lang->line('Interpretation_Support'); ?></h4>
					</td>
				</tr>
			</table>
			<table width="100%"><tr><td height="3"></td></tr></table>

			<table width="100%" cellspacing="0" cellpadding="0" border="0" align="center" style="">
				<?php
				$subAllergnsArr = $this->AllergensModel->getAllergensByID(json_encode($allengesIDsArr));
				if(!empty($subAllergnsArr)){
					foreach ($subAllergnsArr as $rsvalue){
						echo '<tr>
							<td>
								<h4 style="margin:10px 0px 0px 0px;color:#2a5b74;">'.$rsvalue['pax_name'].'</h4>
								<ol style="color:#184359;font-size:13px;margin:0px 0 0 20px;padding:0;">';
									$descIDArr = array();
									$descVluArr = $this->OrdersModel->getRaptorInterpretationDescription($rsvalue['id'],$raptorData->result_id);
									if(!empty($descVluArr)){
										foreach ($descVluArr as $rowd){
											if($rowd->result_value >= 30){
												$descIDArr[] = $rowd->id;
											}
										}
									}

									$extIDArr = array();
									$extVluArr = $this->OrdersModel->getRaptorInterpretationExtract($rsvalue['id'],$raptorData->result_id);
									if(!empty($extVluArr)){
										foreach ($extVluArr as $rowe){
											if($rowe->result_value >= 30){
												$extIDArr[] = $rowe->id;
											}
										}
									}

									$compIDArr = array();
									$compVluArr = $this->OrdersModel->getRaptorInterpretationComponents($rsvalue['id'],$raptorData->result_id);
									if(!empty($compVluArr)){
										foreach ($compVluArr as $rowc){
											if($rowc->result_value >= 30){
												$compIDArr[] = $rowc->id;
											}
										}
									}

									if(!empty($extIDArr) && empty($descIDArr) && empty($compIDArr)){
										$extVluArr = $this->OrdersModel->getRaptorInterpretationExtract($rsvalue['id'],$raptorData->result_id);
										if(!empty($extVluArr)){
											foreach ($extVluArr as $rowe){
												if($rowe->result_value >= 30){
													if($rowe->raptor_header != "" && $rowe->raptor_header != '[""]'){
														$detaildArr = json_decode($rowe->raptor_header);
														if(!empty($detaildArr)){
															foreach($detaildArr as $row1d){
																echo '<li style="list-style-type: disc;">'.$row1d.'</li>';
															}
														}
														echo '<br>';
													}
												}
											}
										}
									}elseif(!empty($descIDArr) && empty($compIDArr) && empty($extIDArr)){
										$descVluArr = $this->OrdersModel->getRaptorInterpretationDescription($rsvalue['id'],$raptorData->result_id);
										if(!empty($descVluArr)){
											foreach ($descVluArr as $rowd){
												if($rowd->raptor_header != "" && $rowd->raptor_header != '[""]'){
													$detaildArr = json_decode($rowd->raptor_header);
													if(!empty($detaildArr)){
														foreach($detaildArr as $row1d){
															echo '<li style="list-style-type: disc;">'.$row1d.'</li>';
														}
													}
													echo '<br>';
												}
											}
										}
									}else{
										$descVluArr = $this->OrdersModel->getRaptorInterpretationDescription($rsvalue['id'],$raptorData->result_id);
										if(!empty($descVluArr)){
											foreach ($descVluArr as $rowd){
												if($rowd->raptor_header != "" && $rowd->raptor_header != '[""]'){
													$detaildArr = json_decode($rowd->raptor_header);
													if(!empty($detaildArr)){
														foreach($detaildArr as $row1d){
															echo '<li style="list-style-type: disc;">'.$row1d.'</li>';
														}
													}
													echo '<br>';
												}
											}
										}

										$extVluArr = $this->OrdersModel->getRaptorInterpretationExtract($rsvalue['id'],$raptorData->result_id);
										if(!empty($extVluArr)){
											foreach ($extVluArr as $rowe){
												if($rowe->raptor_header != "" && $rowe->raptor_header != '[""]'){
													$detaildArr = json_decode($rowe->raptor_header);
													if(!empty($detaildArr)){
														foreach($detaildArr as $row1d){
															echo '<li style="list-style-type: disc;">'.$row1d.'</li>';
														}
													}
													echo '<br>';
												}
											}
										}

										$compVluArr = $this->OrdersModel->getRaptorInterpretationComponents($rsvalue['id'],$raptorData->result_id);
										if(!empty($compVluArr)){
											foreach ($compVluArr as $rowc){
												if($rowc->raptor_header != "" && $rowc->raptor_header != '[""]'){
													$detaildArr = json_decode($rowc->raptor_header);
													if(!empty($detaildArr)){
														foreach($detaildArr as $row1d){
															echo '<li style="list-style-type: disc;">'.$row1d.'</li>';
														}
													}
													echo '<br>';
												}
											}
										}
									}

									/* $subpVluArr = $this->OrdersModel->getRaptorInterpretation($rsvalue['id'],$raptorData->result_id);
									if(!empty($subpVluArr)){
										foreach ($subpVluArr as $srow){
											if($srow->result_value >= 30){
												if($srow->raptor_header != "" && $srow->raptor_header != '[""]'){
													$detaildArr = json_decode($srow->raptor_header);
													if(!empty($detaildArr)){
														foreach($detaildArr as $row1d){
															echo '<li style="list-style-type: disc;">'.$row1d.'</li>';
														}
													}
													echo '<br>';
												}
											}
										}
									}

									$subpEDVluArr = $this->OrdersModel->getRaptorInterpretationED($rsvalue['id'],$raptorData->result_id);
									if(!empty($subpEDVluArr)){
										foreach ($subpEDVluArr as $sedrow){
											if($sedrow->result_value >= 30){
												if($sedrow->raptor_header != "" && $sedrow->raptor_header != '[""]'){
													$detaildedArr = json_decode($sedrow->raptor_header);
													if(!empty($detaildedArr)){
														foreach($detaildedArr as $row2d){
															echo '<li style="list-style-type: disc;">'.$row2d.'</li>';
														}
													}
													echo '<br>';
												}
											}
										}
									} */
								echo '</ol>
							</td>
						</tr>';
					}
				}
				?>
			</table>
			<table width="100%"><tr><td height="3"></td></tr></table>
			<table width="100%">
				<tr>
					<td>
						<p style="color:#273945; margin:0 0 12px 0; padding:0; font-size:16px; line-height:22px;"><?php echo $this->lang->line('interpretation_DISCLAIMER'); ?> </p>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<table width="100%"><tr><td height="20"></td></tr></table>