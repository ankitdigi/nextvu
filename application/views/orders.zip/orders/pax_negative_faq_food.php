<table class="main_container" cellspacing="0" cellpadding="0" border="0" align="center" style="width:100%;max-width:100%;background:url(<?php echo base_url(); ?>assets/images/pax-bg.png) center top no-repeat #ffffff;background-size:100%;padding:5px;">
	<tr>
		<td style="padding: 5px;">
			<table width="100%" cellspacing="0" cellpadding="0" border="0" align="center" style="">
				<tr>
					<th valign="bottom" align="left" style="padding:0 0 5px 0; border-bottom:2px solid #3a6a86; font-weight:400;"><img src="<?php echo base_url(); ?>assets/images/pax-logo.png" alt="" style="max-height:60px;"></th>
					<th valign="bottom" style="padding:0 0 5px 0; border-bottom:2px solid #3a6a86; font-weight:400;"><b><?php echo $order_details['pet_name']; ?></b><?php echo $order_details['pet_owner_name'].' '.$order_details['po_last']; ?></th>
					<th valign="bottom" style="padding:0 0 5px 0; border-bottom:2px solid #3a6a86; font-weight:400;"><b><?php echo $this->lang->line('customer'); ?>:</b> <?php echo $order_details['order_number']; ?></th>
					<th valign="bottom" style="padding:0 0 5px 0; border-bottom:2px solid #3a6a86; font-weight:400;"><b><?php echo $this->lang->line('test'); ?>:</b> <?php echo $raptorData->sample_code; ?></th>
				</tr>
			</table>
			<table width="100%"><tr><td height="20"></td></tr></table>

			<table width="100%" cellspacing="0" cellpadding="0" border="0" align="center" style="">
					<tr>
					<td>
						<h4 style="margin:0; color:#2a5b74; font-size:24px;"><?php echo $this->lang->line('negative_result_title'); ?></h4>
					</td>
				</tr>
			</table>
			<table width="100%"><tr><td height="20"></td></tr></table>

			<table class="" cellspacing="0" cellpadding="0" border="0" align="left" width="100%" style="padding:15px;">
				<tr>
					<td>
						<p style="color:#1e3743; font-size:13px; margin:4px 0 0 0;"><?php echo $this->lang->line('result_note3_food'); ?></p>
					</td>
				</tr>
			</table>
			<table width="100%"><tr><td height="20"></td></tr></table>
			<table width="100%"><tr><td><h6 style="color:#2a5b74; font-weight:400; font-size:20px; margin:0;"><?php echo $this->lang->line('faq_title'); ?></h6></td></tr></table>
			<table class="" cellspacing="0" cellpadding="0" border="0" align="left" width="47%">
				<tr>
					<td width="35" style="line-height:0;"><img src="<?php echo base_url(); ?>assets/images/question.png" alt="" /></td>
					<td><h6 style="color:#333333; font-size:16px; margin:0;"><?php echo $this->lang->line('negative_q1'); ?></h6></td>	
				</tr>
				<tr>
					<td colspan="2"><p style="color:#333333; font-size:14px; line-height:21px; margin:10px 0 0 0;"><?php echo $this->lang->line('negative_a1'); ?></p></td>
				</tr>

				<tr><td height="30"></td></tr>
				<tr>
					<td width="35" style="line-height:0;"><img src="<?php echo base_url(); ?>assets/images/question.png" alt="" /></td>
					<td><h6 style="color:#333333; font-size:16px; margin:0;"><?php echo $this->lang->line('negative_q2'); ?></h6></td>	
				</tr>
				<tr>
					<td colspan="2"><p style="color:#333333; font-size:14px; line-height:21px; margin:10px 0 0 0;"><?php echo $this->lang->line('negative_a2'); ?></p></td>
				</tr>
			</table>
			<table class="" cellspacing="0" cellpadding="0" border="0" align="right" width="47%">
				<tr>
					<td width="35" style="line-height:0;"><img src="<?php echo base_url(); ?>assets/images/question.png" alt="" /></td>
					<td><h6 style="color:#333333; font-size:16px; margin:0;"><?php echo $this->lang->line('negative_q3'); ?></h6></td>
				</tr>
				<tr>
					<td colspan="2"><p style="color:#333333; font-size:14px; line-height:21px; margin:10px 0 0 0;"><?php echo $this->lang->line('negative_a3'); ?></p></td>
				</tr>

				<tr><td height="30"></td></tr>
				<tr>
					<td width="35" style="line-height:0;"><img src="<?php echo base_url(); ?>assets/images/question.png" alt="" /></td>
					<td><h6 style="color:#333333; font-size:16px; margin:0;"><?php echo $this->lang->line('negative_q4'); ?></h6></td>	
				</tr>
				<tr>
					<td colspan="2"><p style="color:#333333; font-size:14px; line-height:21px; margin:10px 0 0 0;"><?php echo $this->lang->line('negative_a4'); ?></p></td>
				</tr>
			</table>
			<table width="100%"><tr><td height="50"></td></tr></table>
			<table width="100%">
				<tr>
					<td>
						<h6 style="color:#366784; margin:0 0 15px 0; padding:0; font-size:18px;"><?php echo $this->lang->line('positive_q12'); ?></h6>
						<p style="color:#273945; margin:0 0 12px 0; padding:0; font-size:16px; line-height:22px;"><?php echo $this->lang->line('contact1'); ?> <a style="color:currentcolor" href="mailto:vetorders.uk@nextmune.com"><?php echo $this->lang->line('contact_email'); ?></a></p>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<table width="100%"><tr><td height="20"></td></tr></table>