<!DOCTYPE html>
<html class="js">
	<head>
		<title>Nextlab Order Requisition Form</title>
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
		<style>
		@page {margin:0mm;}
		body{margin: 0px;}
		*{font-family:'Open Sans',sans-serif}
		</style>
	</head>
	<body bgcolor="#cccccc">
		<?php 
		if($order_details['pet_id']>0){
			$this->db->select('type,breed_id,other_breed,gender,age,age_year');
			$this->db->from('ci_pets');
			$this->db->where('id', $order_details['pet_id']);
			$petinfo = $this->db->get()->row_array();

			if($petinfo['breed_id']>0){
				$this->db->select('name');
				$this->db->from('ci_breeds');
				$this->db->where('id', $petinfo['breed_id']);
				$breedinfo = $this->db->get()->row_array();
			}else{
				$breedinfo = array();
			}
		}else{
			$petinfo = array();
			$breedinfo = array();
		}

		if($order_details['vet_user_id']>0){
			$refDatas = $this->UsersDetailsModel->getColumnAllArray($order_details['vet_user_id']);
			$refDatas = array_column($refDatas, 'column_field', 'column_name');
			$add_1 = !empty($refDatas['add_1']) ? $refDatas['add_1'].', ' : '';
			$add_2 = !empty($refDatas['add_2']) ? $refDatas['add_2'].', ' : '';
			$add_3 = !empty($refDatas['add_3']) ? $refDatas['add_3'] : '';
			$city = !empty($refDatas['add_4']) ? $refDatas['add_4'] : '';
			$postcode = !empty($refDatas['address_3']) ? $refDatas['address_3'] : '';
			$fulladdress = $add_1.$add_2.$add_3;
		}else{
			$fulladdress = '';
			$city = '';
			$postcode = '';
		}

		if(!empty($order_details['product_code_selection'])){
			$this->db->select('name');
			$this->db->from('ci_price');
			$this->db->where('id', $order_details['product_code_selection']);
			$ordeType = $this->db->get()->row()->name;
		}else{
			$ordeType = 'Serum Testing';
		}
		$serumdata = $this->OrdersModel->getSerumTestRecord($order_details['id']);
		$years = !empty($petinfo['age_year'])?$petinfo['age_year'].'Year, ':'';
		$months = !empty($petinfo['age'])?$petinfo['age'].'Month':'';
		?>
		<table class="main_container" width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
			<tbody>
				<tr>
					<td width="100%">
						<table class="header" cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
							<tbody>
								<tr>
									<td width="100%">
										<table width="100%" cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>
													<td align="left" valign="middle" style="background:#426e89; padding: 5mm 0mm 5mm 8mm;">
														<p style="font-size: 32px;text-transform: uppercase;color: #ffffff;font-weight: 400; margin: 0; letter-spacing: 2px; line-height: 38px; white-space:nowrap;">Serum test<br> Request form</p>
													</td>
													<td valign="top"><img src="<?php echo base_url("/assets/images/aqua-corner-shape.png"); ?>" alt="NextVu" height="180" /></td>
													<td width="7%">&nbsp;</td>
													<td align="right" style="padding: 0 8mm 0 0;">
														<img src="<?php echo base_url("/assets/images/nextmune-uk.png"); ?>" height="55" alt="NextVu" />
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<?php /* <table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding: 8mm 8mm 2mm;">
			<tbody>
				<tr>
					<td width="100%">
						<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
							<tbody>
								<tr>
									<td width="100%">
										<table cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>
													<td style="color:#426e89; letter-spacing:1px; font-size:16px;"><b>Order Type:</b> <?php echo $ordeType; ?></td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table> */ ?>
		<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:2mm 8mm;">
			<tbody>
				<tr>
					<td width="100%">
						<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
							<tbody>
								<tr>
									<td width="100%">
										<table cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>
													<td style="color:#426e89; letter-spacing:1px; font-size:20px;">Practice details</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="padding: 0mm 8mm;">
			<tr>
				<td width="49%" valign="top">
					<table width="100%">
						<tbody>
							<tr>
								<td width="100%">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td width="49%" valign="middle">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tbody>
															<tr>
																<td width="100%" valign="top">
																	<p style="color:#346a7e; font-size:14px; line-height: 24px;">Date:</p>
																</td>
															</tr>
															<tr>
																<td style="height: 5px; line-height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
																	<?php echo date('d/m/Y',strtotime($order_details['order_date'])); ?>
																</td>
															</tr>
														</tbody>
													</table>
												</td>
												<td width="2%">&nbsp;</td>
												<td width="49%" valign="middle">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tbody>
															<tr>
																<td width="100%" valign="top">
																	<p style="color:#346a7e; font-size:14px; line-height: 24px;">Veterinary surgeon:</p>
																</td>
															</tr>
															<tr>
																<td style="height: 5px; line-height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
																	<?php echo $order_details['name']; ?>
																</td>
															</tr>
														</tbody>
													</table>
												</td>
											</tr>
											<tr>
												<td style="height:5px; line-height:5px;"></td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td width="100%" valign="middle">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td width="100%" valign="top">
													<p style="color:#346a7e; font-size:14px; line-height: 24px;">Veterinary practice:</p>
												</td>
											</tr>
											<tr>
												<td style="height:5px; line-height:5px;"></td>
											</tr>
											<tr>
												<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
													<?php echo $order_details['practice_name']; ?>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td style="height:5px; line-height:5px;"></td>
							</tr>
							<tr>
								<td width="100%" valign="middle">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td width="100%" valign="top">
													<p style="color:#346a7e; font-size:14px; line-height: 24px;">Practice details:</p>
												</td>
											</tr>
											<tr>
												<td style="height: 5px; line-height: 5px;"></td>
											</tr>
											<tr>
												<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
													<?php echo $fulladdress; ?>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td style="height:5px; line-height:5px;"></td>
							</tr>
							<tr>
								<td width="100%">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td width="49%" valign="middle">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tbody>
															<tr>
																<td width="100%" valign="top">
																	<p style="color:#346a7e; font-size:14px; line-height: 24px;">City:</p>
																</td>
															</tr>
															<tr>
																<td style="height: 5px; line-height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
																	<?php echo $city; ?>
																</td>
															</tr>
														</tbody>
													</table>
												</td>
												<td width="2%">&nbsp;</td>
												<td width="49%" valign="middle">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tbody>
															<tr>
																<td width="100%" valign="top">
																	<p style="color:#346a7e; font-size:14px; line-height: 24px;">Postcode:</p>
																</td>
															</tr>
															<tr>
																<td style="height: 5px; line-height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
																	<?php echo $postcode; ?>
																</td>
															</tr>
														</tbody>
													</table>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td width="2%">&nbsp;</td>
				<td width="49%" valign="top">
					<table width="100%">
						<tbody>
							<tr>
								<td width="100%" valign="middle">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td width="100%" valign="top">
													<p style="color:#346a7e; font-size:14px; line-height: 24px;">Phone:</p>
												</td>
											</tr>
											<tr>
												<td style="height:5px; line-height:5px;"></td>
											</tr>
											<tr>
												<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
													<?php echo $order_details['phone_number']; ?>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td style="height:5px; line-height:5px;"></td>
							</tr>
							<tr>
								<td width="100%" valign="middle">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td width="100%" valign="top">
													<p style="color:#346a7e; font-size:14px; line-height: 24px;">Email:</p>
												</td>
											</tr>
											<tr>
												<td style="height: 5px; line-height: 5px;"></td>
											</tr>
											<tr>
												<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
													<?php echo $order_details['email']; ?>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
							<tr>
								<td style="height:5px; line-height:5px;"></td>
							</tr>
							<tr>
								<td width="100%" valign="middle">
									<table width="100%" cellspacing="0" cellpadding="0" border="0">
										<tbody>
											<tr>
												<td width="100%" valign="top">
													<p style="color:#346a7e; font-size:14px; line-height: 24px;">Results will be delivered by email.</p>
												</td>
											</tr>
											<tr>
												<td style="height: 5px; line-height: 5px;"></td>
											</tr>
											<tr>
												<td width="100%">
													<table width="100%" cellspacing="0" cellpadding="0" border="0">
														<tbody>
															<tr>
																<td width="6%" valign="top">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tbody>
																			<tr>
																				<td>
																					<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																				</td>
																			</tr>
																		</tbody>
																	</table>
																</td>
																<td width="2%">&nbsp;</td>
																<td width="92%" valign="top">
																	<?php /* <table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tbody>
																			<tr>
																				<td style="color:#346a7e; font-size:14px;">
																					I would like to order more serum test shipping materials
																				</td>
																			</tr>
																		</tbody>
																	</table> */ ?>
																</td>
															</tr>
														</tbody>
													</table>
												</td>
											</tr>
										</tbody>
									</table>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
			</tr>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
			<tbody>
				<tr>
					<td style="height: 25px;"></td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="padding:0mm 8mm">
			<tbody>
				<tr>
					<td width="100%">
						<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
							<tbody>
								<tr>
									<td width="100%">
										<table cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>
													<td style="color:#426e89; letter-spacing:1px; font-size:20px;">Pet and pet owner details</td>
												</tr>
												<tr>
													<td style="height: 10px; line-height: 10px;"></td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="padding: 0mm 8mm;">
			<tbody>
				<tr>
					<td width="49%" valign="top">
						<table width="100%">
							<tbody>
								<tr>
									<td width="100%">
										<table width="100%" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="49%" valign="middle">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td width="100%" valign="top">
																		<p style="color:#346a7e; font-size:14px; line-height: 24px;">Pet owner’s first name:</p>
																	</td>
																</tr>
																<tr>
																	<td style="height: 5px; line-height: 5px;"></td>
																</tr>
																<tr>
																	<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
																		<?php echo $order_details['pet_owner_name']; ?>
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="2%">&nbsp;</td>
													<td width="49%" valign="middle">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td width="100%" valign="top">
																		<p style="color:#346a7e; font-size:14px; line-height: 24px;">Pet owners last name:</p>
																	</td>
																</tr>
																<tr>
																	<td style="height: 5px; line-height: 5px;"></td>
																</tr>
																<tr>
																	<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
																		<?php echo $order_details['po_last']; ?>
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr>
													<td style="height:5px; line-height:5px;"></td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
								<tr>
									<td width="100%">
										<table width="100%" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="100%" valign="middle">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td width="100%" valign="top">
																		<p style="color:#346a7e; font-size:14px; line-height: 24px;">Species:</p>
																	</td>
																</tr>
																<tr>
																	<td style="height: 5px; line-height: 5px;"></td>
																</tr>
																<tr>
																	<td width="100%">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tbody>
																				<tr>
																					<td width="33%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="20%">
																										<?php if($order_details['species_name'] == 'Dog'){ ?>
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																										<?php }else{ ?>
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																										<?php } ?>
																									</td>
																									<td width="80%" style="color:#346a7e; font-size:14px;">
																										Dog
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																					<td width="33%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="20%">
																										<?php if($order_details['species_name'] == 'Cat'){ ?>
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																										<?php }else{ ?>
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																										<?php } ?>
																									</td>
																									<td width="80%" style="color:#346a7e; font-size:14px;">
																										Cat
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																					<td width="33%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="20%">
																										<?php if($order_details['species_name'] == 'Horse'){ ?>
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																										<?php }else{ ?>
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																										<?php } ?>
																									</td>
																									<td width="80%" style="color:#346a7e; font-size:14px;">
																										Horse
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr>
													<td style="height:5px; line-height:5px;"></td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
								<tr>
									<td width="100%">
										<table width="100%" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="49%" valign="middle">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td width="100%" valign="top">
																		<p style="color:#346a7e; font-size:14px; line-height: 24px;">Breed:</p>
																	</td>
																</tr>
																<tr>
																	<td style="height: 5px; line-height: 5px;"></td>
																</tr>
																<tr>
																	<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
																		<?php echo $breedinfo['name']; ?>
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="2%">&nbsp;</td>
													<td width="49%" valign="middle">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td width="100%" valign="top">
																		<p style="color:#346a7e; font-size:14px; line-height: 24px;">Age Month and Year:</p>
																	</td>
																</tr>
																<tr>
																	<td style="height: 5px; line-height: 5px;"></td>
																</tr>
																<tr>
																	<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
																		<?php echo $years.$months; ?>
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr>
													<td style="height:5px; line-height:5px;"></td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
					<td width="2%">&nbsp;</td>
					<td width="49%" valign="top">
						<table width="100%">
							<tbody>
								<tr>
									<td width="100%" valign="middle">
										<table width="100%" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="100%" valign="top">
														<p style="color:#346a7e; font-size:14px; line-height: 24px;">Animal name:</p>
													</td>
												</tr>
												<tr>
													<td style="height: 5px; line-height: 5px;"></td>
												</tr>
												<tr>
													<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
														<?php echo $order_details['pet_name']; ?>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
								<tr>
									<td style="height:5px; line-height:5px;"></td>
								</tr>
								<tr>
									<td width="100%">
										<table width="100%" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="100%" valign="middle">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td width="100%" valign="top">
																		<p style="color:#346a7e; font-size:14px; line-height: 24px;">Gender:</p>
																	</td>
																</tr>
																<tr>
																	<td style="height: 5px; line-height: 5px;"></td>
																</tr>
																<tr>
																	<td width="100%">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tbody>
																				<tr>
																					<td width="50%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="15%">
																										<?php if($petinfo['gender'] == '1'){ ?>
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																										<?php }else{ ?>
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																										<?php } ?>
																									</td>
																									<td width="85%" style="color:#346a7e; font-size:14px;">
																										Male
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																					<td width="50%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="15%">
																										<?php if($petinfo['gender'] == '2'){ ?>
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																										<?php }else{ ?>
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																										<?php } ?>
																									</td>
																									<td width="85%" style="color:#346a7e; font-size:14px;">
																										Female
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr>
													<td style="height:5px; line-height:5px;"></td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
								<tr>
									<td width="100%" valign="middle">
										<table width="100%" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="100%" valign="top">
														<p style="color:#346a7e; font-size:14px; line-height: 24px;">Date serum drawn:</p>
													</td>
												</tr>
												<tr>
													<td style="height: 5px; line-height: 5px;"></td>
												</tr>
												<tr>
													<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
														<?php echo !empty($serumdata['serum_drawn_date'])?date('d/m/Y',strtotime($serumdata['serum_drawn_date'])):''; ?>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
			<tbody>
				<tr>
					<td style="height: 25px;"></td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="padding:0mm 8mm;">
			<tbody>
				<tr>
					<td width="100%">
						<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
							<tbody>
								<tr>
									<td width="100%">
										<table cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>
													<td style="color:#426e89; letter-spacing:1px; font-size:20px;">Medical history</td>
												</tr>
												<tr>
													<td style="height: 10px; line-height: 10px;"></td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="padding: 0mm 8mm;">
			<tbody>
				<tr>
					<td width="100%">
						<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
							<tbody>
								<tr>
									<td width="100%" valign="middle">
										<table width="100%" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="100%" valign="top">
														<p style="color:#346a7e; font-size:14px; line-height: 24px;">With which one(s) of the following is the patient affected?</p>
													</td>
												</tr>
												<tr>
													<td style="height:5px; line-height: 5px;"></td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td width="100%" valign="middle">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tbody>
																				<tr>
																					<td width="100%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="20%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="15%">
																														<?php if( isset($serumdata['major_symptoms']) && (strpos( $serumdata['major_symptoms'], '1' ) !== false) ){ ?>
																														<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																														<?php }else{ ?>
																														<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																														<?php } ?>
																													</td>
																													<td width="85%" style="color:#346a7e; font-size:14px;">
																														Pruritus (itch)
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																									<td width="20%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="15%">
																														<?php if( isset($serumdata['major_symptoms']) && (strpos( $serumdata['major_symptoms'], '5' ) !== false) ){ ?>
																														<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																														<?php }else{ ?>
																														<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																														<?php } ?>
																													</td>
																													<td width="85%" style="color:#346a7e; font-size:14px;">
																														Skin lesions
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																									<td width="20%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="15%">
																														<?php if( isset($serumdata['major_symptoms']) && (strpos( $serumdata['major_symptoms'], '2' ) !== false) ){ ?>
																														<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																														<?php }else{ ?>
																														<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																														<?php } ?>
																													</td>
																													<td width="85%" style="color:#346a7e; font-size:14px;">
																														Otitis
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																									<td width="20%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="15%">
																														<?php if( isset($serumdata['major_symptoms']) && (strpos( $serumdata['major_symptoms'], '3' ) !== false) ){ ?>
																														<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																														<?php }else{ ?>
																														<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																														<?php } ?>
																													</td>
																													<td width="85%" style="color:#346a7e; font-size:14px;">
																														Respiratory signs
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																									<td width="20%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="15%">
																														<?php if( isset($serumdata['major_symptoms']) && (strpos( $serumdata['major_symptoms'], '6' ) !== false) ){ ?>
																														<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																														<?php }else{ ?>
																														<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																														<?php } ?>
																													</td>
																													<td width="85%" style="color:#346a7e; font-size:14px;">
																														Ocular signs
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
																<tr>
																	<td width="100%" style="height: 10px; line-height:10px;"></td>
																</tr>
																<tr>
																	<td width="100%" valign="middle">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tbody>
																				<tr>
																					<td width="100%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="20%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="15%">
																														<?php if( isset($serumdata['major_symptoms']) && (strpos( $serumdata['major_symptoms'], '7' ) !== false) ){ ?>
																														<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																														<?php }else{ ?>
																														<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																														<?php } ?>
																													</td>
																													<td width="85%" style="color:#346a7e; font-size:14px;">
																														Anaphylaxis
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																									<td width="20%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="15%" valign="top">
																														<?php if( isset($serumdata['major_symptoms']) && (strpos( $serumdata['major_symptoms'], '4' ) !== false) ){ ?>
																														<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																														<?php }else{ ?>
																														<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																														<?php } ?>
																													</td>
																													<td valign="top" width="85%" style="color:#346a7e; font-size:14px;">
																														Gastro-intestinal signs
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																									<td width="60%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="30%" valign="middle">
																														<table width="100%" cellspacing="0" cellpadding="0" border="0" align="right">
																															<tbody>
																																<tr>
																																	<td width="15%" valign="middle">
																																		<?php if( isset($serumdata['major_symptoms']) && (strpos( $serumdata['major_symptoms'], '0' ) !== false) ){ ?>
																																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																																		<?php }else{ ?>
																																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																																		<?php } ?>
																																	</td>
																																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px;">
																																		Other
																																	</td>
																																</tr>
																															</tbody>
																														</table>
																													</td>
																													<td valign="top" width="70%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
																														<?php echo isset($serumdata['other_symptom']) ? $serumdata['other_symptom'] : ''; ?>
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
																<tr>
																	<td style="height:5px; line-height:5px;"></td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
								<tr>
									<td width="100%" style="height:10px; line-height: 10px;"></td>
								</tr>
								<tr>
									<td width="100%" valign="middle">
										<table width="100%" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="100%" valign="top">
														<p style="color:#346a7e; font-size:14px; line-height: 24px;">At what age did these symptoms first appear?</p>
													</td>
												</tr>
												<tr>
													<td style="height:5px; line-height: 5px;"></td>
												</tr>
												<tr>
													<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
														<?php echo $serumdata['symptom_appear_age'].' years '.$serumdata['symptom_appear_age_month'].' months'; ?>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
								<tr>
									<td width="100%" style="height:10px; line-height: 10px;"></td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="padding:2mm 8mm;">
			<tbody>
				<tr>
					<td width="48%" valign="top">
						<table width="100%">
							<tbody>
								<tr>
									<td width="100%">
										<table width="100%" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="100%" valign="middle">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td width="100%" valign="top">
																		<p style="color:#346a7e; font-size:14px; line-height: 24px;">When are the symptoms most obvious?</p>
																	</td>
																</tr>
																<tr>
																	<td style="height: 5px; line-height: 5px;"></td>
																</tr>
																<tr>
																	<td width="100%">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tbody>
																				<tr>
																					<td width="33%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="20%">
																										<?php if( isset($serumdata['when_obvious_symptoms']) && (strpos( $serumdata['when_obvious_symptoms'], '1' ) !== false) ){ ?>
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																										<?php }else{ ?>
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																										<?php } ?>
																									</td>
																									<td width="80%" style="color:#346a7e; font-size:14px;">
																										Spring
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																					<td width="33%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="20%">
																										<?php if( isset($serumdata['when_obvious_symptoms']) && (strpos( $serumdata['when_obvious_symptoms'], '2' ) !== false) ){ ?>
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																										<?php }else{ ?>
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																										<?php } ?>
																									</td>
																									<td width="80%" style="color:#346a7e; font-size:14px;">
																										Summer
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																					<td width="33%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="20%">
																										<?php if( isset($serumdata['when_obvious_symptoms']) && (strpos( $serumdata['when_obvious_symptoms'], '3' ) !== false) ){ ?>
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																										<?php }else{ ?>
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																										<?php } ?>
																									</td>
																									<td width="80%" style="color:#346a7e; font-size:14px;">
																										Fall
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
																<tr>
																	<td style="height: 5px; line-height: 5px;"></td>
																</tr>
																<tr>
																	<td width="100%">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tbody>
																				<tr>
																					<td width="50%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="20%">
																										<?php if( isset($serumdata['when_obvious_symptoms']) && (strpos( $serumdata['when_obvious_symptoms'], '4' ) !== false) ){ ?>
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																										<?php }else{ ?>
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																										<?php } ?>
																									</td>
																									<td width="80%" style="color:#346a7e; font-size:14px;">
																										Winter
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																					<td width="50%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="20%">
																										<?php if( isset($serumdata['when_obvious_symptoms']) && (strpos( $serumdata['when_obvious_symptoms'], '5' ) !== false) ){ ?>
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																										<?php }else{ ?>
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																										<?php } ?>
																									</td>
																									<td width="80%" style="color:#346a7e; font-size:14px;">
																										Year-round
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr>
													<td style="height:10px; line-height:10px;"></td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
					<td width="4%">&nbsp;</td>
					<td width="48%" valign="top">
						<table width="100%">
							<tbody>
								<tr>
									<td width="100%">
										<table width="100%" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="100%" valign="middle">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td width="100%" valign="top">
																		<p style="color:#346a7e; font-size:14px; line-height: 24px;">When are the symptoms most obvious?</p>
																	</td>
																</tr>
																<tr>
																	<td style="height: 5px; line-height: 5px;"></td>
																</tr>
																<tr>
																	<td width="100%">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tbody>
																				<tr>
																					<td width="33%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="20%">
																										<?php if( isset($serumdata['where_obvious_symptoms']) && (strpos( $serumdata['where_obvious_symptoms'], '1' ) !== false) ){ ?>
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																										<?php }else{ ?>
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																										<?php } ?>
																									</td>
																									<td width="80%" style="color:#346a7e; font-size:14px;">
																										Indoors
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																					<td width="33%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="20%">
																										<?php if( isset($serumdata['where_obvious_symptoms']) && (strpos( $serumdata['where_obvious_symptoms'], '2' ) !== false) ){ ?>
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																										<?php }else{ ?>
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																										<?php } ?>
																									</td>
																									<td width="80%" style="color:#346a7e; font-size:14px;">
																										Outdoors
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																					<td width="33%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="20%">
																										<?php if( isset($serumdata['where_obvious_symptoms']) && (strpos( $serumdata['where_obvious_symptoms'], '3' ) !== false) ){ ?>
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																										<?php }else{ ?>
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																										<?php } ?>
																									</td>
																									<td width="80%" style="color:#346a7e; font-size:14px;">
																										No Difference
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="padding:2mm 8mm;">
			<tbody>
				<tr>
					<td width="48%" valign="top">
						<table width="100%">
							<tbody>
								<tr>
									<td width="100%">
										<table width="100%" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="100%" valign="middle">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td width="100%" valign="top">
																		<p style="color:#346a7e; font-size:14px; line-height: 24px;">Has there been a clinical diagnosis of allergy to the following?</p>
																	</td>
																</tr>
																<tr>
																	<td style="height: 10px; line-height: 10px;"></td>
																</tr>
																<tr>
																	<td width="100%" valign="top">
																		<p style="color:#346a7e; font-size:14px; line-height: 24px;">Food(s):</p>
																	</td>
																</tr>
																<tr>
																	<td width="100%">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tbody>
																				<tr>
																					<td width="25%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="20%">
																										<?php if( isset($serumdata['diagnosis_food']) && (strpos( $serumdata['diagnosis_food'], '1' ) !== false) ){ ?>
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																										<?php }else{ ?>
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																										<?php } ?>
																									</td>
																									<td width="80%" style="color:#346a7e; font-size:14px;">
																										Yes
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																					<td width="75%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="30%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="20%">
																														<?php if( isset($serumdata['diagnosis_food']) && (strpos( $serumdata['diagnosis_food'], '2' ) !== false) ){ ?>
																														<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																														<?php }else{ ?>
																														<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																														<?php } ?>
																													</td>
																													<td width="80%" style="color:#346a7e; font-size:14px;">
																														No
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																									<td width="70%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="100%">
																														<p style="color:#346a7e; font-size:14px; line-height: 24px;">Specify which one(s) if known:</p>
																													</td>
																												</tr>
																												<tr>
																													<td width="100%" style="height:5px; line-height:5px;"></td>
																												</tr>
																												<tr>
																													<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
																														<?php echo isset($serumdata['other_diagnosis_food']) ? $serumdata['other_diagnosis_food'] : '';?>
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																								</tr>
																							</tbody>	
																						</table>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
																<tr>
																	<td style="height: 10px; line-height: 10px;"></td>
																</tr>
																<tr>
																	<td width="100%" valign="top">
																		<p style="color:#346a7e; font-size:14px; line-height: 24px;">Hymenoptera stings:</p>
																	</td>
																</tr>
																<tr>
																	<td width="100%">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tbody>
																				<tr>
																					<td width="25%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="20%">
																										<?php if( isset($serumdata['diagnosis_hymenoptera']) && (strpos( $serumdata['diagnosis_hymenoptera'], '1' ) !== false) ){ ?>
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																										<?php }else{ ?>
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																										<?php } ?>
																									</td>
																									<td width="80%" style="color:#346a7e; font-size:14px;">
																										Yes
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																					<td width="75%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="30%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="20%">
																														<?php if( isset($serumdata['diagnosis_hymenoptera']) && (strpos( $serumdata['diagnosis_hymenoptera'], '2' ) !== false) ){ ?>
																														<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																														<?php }else{ ?>
																														<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																														<?php } ?>
																													</td>
																													<td width="80%" style="color:#346a7e; font-size:14px;">
																														No
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																									<td width="70%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="100%">
																														<p style="color:#346a7e; font-size:14px; line-height: 24px;">Specify which one(s) if known:</p>
																													</td>
																												</tr>
																												<tr>
																													<td width="100%" style="height:5px; line-height:5px;"></td>
																												</tr>
																												<tr>
																													<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
																														<?php echo isset($serumdata['other_diagnosis_hymenoptera']) ? $serumdata['other_diagnosis_hymenoptera'] : '';?>
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																								</tr>
																							</tbody>	
																						</table>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
					<td width="4%">&nbsp;</td>
					<td width="48%" valign="top">
						<table width="100%">
							<tbody>
								<tr>
									<td style="height: 60px; line-height: 60px;"></td>
								</tr>
								<tr>
									<td width="100%" valign="top">
										<p style="color:#346a7e; font-size:14px; line-height: 24px;">How fast do signs relapse after a food challenge:</p>
									</td>
								</tr>
								<tr>
									<td width="100%">
										<table width="100%" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="33%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td width="20%">
																		<?php if( isset($serumdata['food_challenge']) && (strpos( $serumdata['food_challenge'], '1' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td width="80%" style="color:#346a7e; font-size:14px;">
																		&lt; 3 h
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="33%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td width="20%">
																		<?php if( isset($serumdata['food_challenge']) && (strpos( $serumdata['food_challenge'], '2' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td width="80%" style="color:#346a7e; font-size:14px;">
																		3-12 h
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="33%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td width="20%">
																		<?php if( isset($serumdata['food_challenge']) && (strpos( $serumdata['food_challenge'], '3' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td width="80%" style="color:#346a7e; font-size:14px;">
																		12-24 h
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr>
													<td style="height:5px; line-height:5px;"></td>
												</tr>
												<tr>
													<td width="50%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td width="20%">
																		<?php if( isset($serumdata['food_challenge']) && (strpos( $serumdata['food_challenge'], '4' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td width="80%" style="color:#346a7e; font-size:14px;">
																		24-48 h
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="50%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td width="20%">
																		<?php if( isset($serumdata['food_challenge']) && (strpos( $serumdata['food_challenge'], '5' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td width="80%" style="color:#346a7e; font-size:14px;">
																		&gt; 48 h
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
								<tr>
									<td style="height: 10px; line-height: 10px;"></td>
								</tr>
								<tr>
									<td width="100%" valign="top">
										<p style="color:#346a7e; font-size:14px; line-height: 24px;">Other(s):</p>
									</td>
								</tr>
								<tr>
									<td width="100%">
										<table width="100%" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td width="20%">
																		<?php if( isset($serumdata['diagnosis_other']) && (strpos( $serumdata['diagnosis_other'], '1' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td width="80%" style="color:#346a7e; font-size:14px;">
																		Yes
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="75%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td width="30%">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tbody>
																				<tr>
																					<td width="20%">
																						<?php if( isset($serumdata['diagnosis_other']) && (strpos( $serumdata['diagnosis_other'], '2' ) !== false) ){ ?>
																						<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																						<?php }else{ ?>
																						<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																						<?php } ?>
																					</td>
																					<td width="80%" style="color:#346a7e; font-size:14px;">
																						No
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																	<td width="70%">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tbody>
																				<tr>
																					<td width="100%">
																						<p style="color:#346a7e; font-size:14px; line-height: 24px;">Specify which one(s) if known:</p>
																					</td>
																				</tr>
																				<tr>
																					<td width="100%" style="height:5px; line-height:5px;"></td>
																				</tr>
																				<tr>
																					<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
																						<?php echo isset($serumdata['other_diagnosis']) ? $serumdata['other_diagnosis'] : '';?>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
															</tbody>	
														</table>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="padding:2mm 8mm;">
			<tbody>
				<tr>
					<td width="100%">
						<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
							<tbody>
								<tr>
									<td width="100%" valign="middle">
										<table width="100%" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="100%" style="height: 10px; line-height:10px;"></td>
												</tr>
												<tr>
													<td width="100%" valign="top">
														<p style="color:#346a7e; font-size:14px; line-height: 24px;">Is the patient regularly exposed to the following animals:</p>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td width="100%" style="height: 10px; line-height:10px;"></td>
																</tr>
																<tr>
																	<td width="100%" valign="middle">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tbody>
																				<tr>
																					<td width="100%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="25%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="20%">
																														<?php if( isset($serumdata['regularly_exposed']) && (strpos( $serumdata['regularly_exposed'], '1' ) !== false) ){ ?>
																														<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																														<?php }else{ ?>
																														<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																														<?php } ?>
																													</td>
																													<td width="80%" style="color:#346a7e; font-size:14px;">
																														Cats
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																									<td width="25%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="20%">
																														<?php if( isset($serumdata['regularly_exposed']) && (strpos( $serumdata['regularly_exposed'], '2' ) !== false) ){ ?>
																														<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																														<?php }else{ ?>
																														<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																														<?php } ?>
																													</td>
																													<td width="80%" style="color:#346a7e; font-size:14px;">
																														Dogs
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																									<td width="25%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="20%">
																														<?php if( isset($serumdata['regularly_exposed']) && (strpos( $serumdata['regularly_exposed'], '3' ) !== false) ){ ?>
																														<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																														<?php }else{ ?>
																														<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																														<?php } ?>
																													</td>
																													<td width="80%" style="color:#346a7e; font-size:14px;">
																														Horses
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																									<td width="25%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="20%">
																														<?php if( isset($serumdata['regularly_exposed']) && (strpos( $serumdata['regularly_exposed'], '4' ) !== false) ){ ?>
																														<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																														<?php }else{ ?>
																														<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																														<?php } ?>
																													</td>
																													<td width="80%" style="color:#346a7e; font-size:14px;">
																														Cattle
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																				</tr>
																				<tr>
																					<td style="height:5px; line-height: 5px;"></td>
																				</tr>
																				<tr>
																					<td width="100%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="33%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="20%">
																														<?php if( isset($serumdata['regularly_exposed']) && (strpos( $serumdata['regularly_exposed'], '5' ) !== false) ){ ?>
																														<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																														<?php }else{ ?>
																														<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																														<?php } ?>
																													</td>
																													<td width="80%" style="color:#346a7e; font-size:14px;">
																														Mice
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																									<td width="33%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="20%">
																														<?php if( isset($serumdata['regularly_exposed']) && (strpos( $serumdata['regularly_exposed'], '6' ) !== false) ){ ?>
																														<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																														<?php }else{ ?>
																														<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																														<?php } ?>
																													</td>
																													<td width="80%" style="color:#346a7e; font-size:14px;">
																														Guinea pigs
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																									<td width="33%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="20%">
																														<?php if( isset($serumdata['regularly_exposed']) && (strpos( $serumdata['regularly_exposed'], '7' ) !== false) ){ ?>
																														<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																														<?php }else{ ?>
																														<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																														<?php } ?>
																													</td>
																													<td width="80%" style="color:#346a7e; font-size:14px;">
																														Rabbits
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
																<tr>
																	<td width="100%">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tbody>
																				<tr>
																					<td width="100%" style="height: 10px; line-height:10px;"></td>
																				</tr>
																				<tr>
																					<td width="100%" valign="middle">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="100%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="25%" valign="middle">
																														<table width="100%" cellspacing="0" cellpadding="0" border="0">
																															<tbody>
																																<tr>
																																	<td valign="middle" width="10%">
																																		<?php if( isset($serumdata['regularly_exposed']) && (strpos( $serumdata['regularly_exposed'], '0' ) !== false) ){ ?>
																																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																																		<?php }else{ ?>
																																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																																		<?php } ?>
																																	</td>
																																	<td valign="middle" width="90%" style="color:#346a7e; font-size:14px; text-align: left;">
																																		Other
																																	</td>
																																</tr>
																															</tbody>
																														</table>
																													</td>
																													<td width="75%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
																														<?php echo isset($serumdata['other_exposed']) ? $serumdata['other_exposed'] : ''; ?>
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
																<tr>
																	<td width="100%" style="height: 10px; line-height:10px;"></td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="padding:2mm 8mm;">
			<tbody>
				<tr>
					<td width="100%" valign="top">
						<table width="100%">
							<tbody>
								<tr>
									<td width="100%">
										<table width="100%" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="100%" valign="middle">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td width="100%" valign="top">
																		<p style="color:#346a7e; font-size:14px; line-height: 24px;">Does the patient suffer from recurrent Malassezia infections?</p>
																	</td>
																</tr>
																<tr>
																	<td style="height: 5px; line-height: 5px;"></td>
																</tr>
																<tr>
																	<td width="100%">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tbody>
																				<tr>
																					<td width="50%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="15%" valign="middle">
																										<?php if( isset($serumdata['malassezia_infections']) && (strpos( $serumdata['malassezia_infections'], '1' ) !== false) ){ ?>
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																										<?php }else{ ?>
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																										<?php } ?>
																									</td>
																									<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																										Malassezia otitis
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																					<td width="50%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td valign="middle" width="15%">
																										<?php if( isset($serumdata['malassezia_infections']) && (strpos( $serumdata['malassezia_infections'], '2' ) !== false) ){ ?>
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																										<?php }else{ ?>
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																										<?php } ?>
																									</td>
																									<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																										Malassezia dermatitis
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="padding:2mm 8mm;">
			<tbody>
				<tr>
					<td width="100%" style="height: 10px; line-height: 10px;"></td>
				</tr>
				<tr>
					<td width="100%">
						<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
							<tbody>
								<tr>
									<td width="100%">
										<p style="color:#346a7e; font-size:14px; line-height: 24px;">Is the patient receiving the following drugs and what was the response to treatment?</p>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
				<tr>
					<td width="100%" style="height: 10px; line-height: 10px;"></td>
				</tr>
				<tr>
					<td width="100%" valign="middle">
						<table width="100%" cellspacing="0" cellpadding="0" border="0">
							<tbody>
								<tr>
									<td width="100%">
										<table width="100%" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs']) && (strpos( $serumdata['receiving_drugs'], '1' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		Glucocorticoids (oral, topical, injectable)
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs_1']) && (strpos( $serumdata['receiving_drugs_1'], '1' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		No response
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs_1']) && (strpos( $serumdata['receiving_drugs_1'], '2' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		Fair response
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs_1']) && (strpos( $serumdata['receiving_drugs_1'], '3' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		Good to excellent response
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs']) && (strpos( $serumdata['receiving_drugs'], '2' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		Ciclosporin
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs_2']) && (strpos( $serumdata['receiving_drugs_2'], '1' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		No response
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs_2']) && (strpos( $serumdata['receiving_drugs_2'], '2' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		Fair response
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs_2']) && (strpos( $serumdata['receiving_drugs_2'], '3' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		Good to excellent response
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs']) && (strpos( $serumdata['receiving_drugs'], '3' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		Oclacitinib
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs_3']) && (strpos( $serumdata['receiving_drugs_3'], '1' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		No response
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs_3']) && (strpos( $serumdata['receiving_drugs_3'], '2' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		Fair response
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs_3']) && (strpos( $serumdata['receiving_drugs_3'], '3' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		Good to excellent response
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs']) && (strpos( $serumdata['receiving_drugs'], '4' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		Lokivetmab
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs_4']) && (strpos( $serumdata['receiving_drugs_4'], '1' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		No response
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs_4']) && (strpos( $serumdata['receiving_drugs_4'], '2' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		Fair response
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs_4']) && (strpos( $serumdata['receiving_drugs_4'], '3' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		Good to excellent response
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs']) && (strpos( $serumdata['receiving_drugs'], '5' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		Antibiotics
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs_5']) && (strpos( $serumdata['receiving_drugs_5'], '1' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		No response
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs_5']) && (strpos( $serumdata['receiving_drugs_5'], '2' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		Fair response
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs_5']) && (strpos( $serumdata['receiving_drugs_5'], '3' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		Good to excellent response
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs']) && (strpos( $serumdata['receiving_drugs'], '6' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		Antifungals
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs_6']) && (strpos( $serumdata['receiving_drugs_6'], '1' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		No response
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs_6']) && (strpos( $serumdata['receiving_drugs_6'], '2' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		Fair response
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
													<td width="25%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td valign="middle" width="15%">
																		<?php if( isset($serumdata['receiving_drugs_6']) && (strpos( $serumdata['receiving_drugs_6'], '3' ) !== false) ){ ?>
																		<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																		<?php }else{ ?>
																		<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																		<?php } ?>
																	</td>
																	<td valign="middle" width="85%" style="color:#346a7e; font-size:14px; text-align: left;">
																		Good to excellent response
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="padding:2mm 8mm;">
			<tbody>
				<tr>
					<td width="48%" valign="top">
						<table width="100%">
							<tbody>
								<tr>
									<td width="100%">
										<table width="100%" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="100%" valign="middle">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td style="height: 10px; line-height: 10px;"></td>
																</tr>
																<tr>
																	<td width="100%" valign="top">
																		<p style="color:#346a7e; font-size:14px; line-height: 24px;">Did the patient receive or is receiving treatment against ectoparasites?</p>
																	</td>
																</tr>
																<tr>
																	<td style="height: 10px; line-height: 10px;"></td>
																</tr>
																<tr>
																	<td width="100%">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tbody>
																				<tr>
																					<td width="25%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="20%">
																										<?php if( isset($serumdata['treatment_ectoparasites']) && (strpos( $serumdata['treatment_ectoparasites'], '1' ) !== false) ){ ?>
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																										<?php }else{ ?>
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																										<?php } ?>
																									</td>
																									<td width="80%" style="color:#346a7e; font-size:14px;">
																										Yes
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																					<td width="75%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="30%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="20%">
																														<?php if( isset($serumdata['treatment_ectoparasites']) && (strpos( $serumdata['treatment_ectoparasites'], '2' ) !== false) ){ ?>
																														<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																														<?php }else{ ?>
																														<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																														<?php } ?>
																													</td>
																													<td width="80%" style="color:#346a7e; font-size:14px;">
																														No
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																									<td width="70%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="100%">
																														<p style="color:#346a7e; font-size:14px; line-height: 24px;">Specify which one(s) if known:</p>
																													</td>
																												</tr>
																												<tr>
																													<td width="100%" style="height:5px; line-height:5px;"></td>
																												</tr>
																												<tr>
																													<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
																														<?php echo isset($serumdata['other_ectoparasites']) ? $serumdata['other_ectoparasites'] : '';?>
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																								</tr>
																							</tbody>	
																						</table>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
																<tr>
																	<td style="height: 10px; line-height: 10px;"></td>
																</tr>
																<tr>
																	<td width="100%" valign="top">
																		<p style="color:#346a7e; font-size:14px; line-height: 24px;">Is this animal suffering from a zoonotic disease?</p>
																	</td>
																</tr>
																<tr>
																	<td style="height: 10px; line-height: 10px;"></td>
																</tr>
																<tr>
																	<td width="100%">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tbody>
																				<tr>
																					<td width="25%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="20%">
																										<?php if(isset($serumdata['zoonotic_disease']) && $serumdata['zoonotic_disease']==1){ ?>
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																										<?php }else{ ?>
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																										<?php } ?>
																									</td>
																									<td width="80%" style="color:#346a7e; font-size:14px;">
																										Yes
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																					<td width="75%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="30%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="20%">
																														<?php if(isset($serumdata['zoonotic_disease']) && $serumdata['zoonotic_disease']==0){ ?>
																														<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																														<?php }else{ ?>
																														<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																														<?php } ?>
																													</td>
																													<td width="80%" style="color:#346a7e; font-size:14px;">
																														No
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																									<td width="70%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="100%">
																														<p style="color:#346a7e; font-size:14px; line-height: 24px;">Specify which one(s) if known:</p>
																													</td>
																												</tr>
																												<tr>
																													<td width="100%" style="height:5px; line-height:5px;"></td>
																												</tr>
																												<tr>
																													<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
																														<?php echo isset($serumdata['zoonotic_disease_dec']) ? $serumdata['zoonotic_disease_dec'] : '';?>
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																								</tr>
																							</tbody>	
																						</table>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
																<tr>
																	<td style="height: 10px; line-height: 10px;"></td>
																</tr>
																<tr>
																	<td width="100%" valign="top">
																		<p style="color:#346a7e; font-size:14px; line-height: 24px;">Any additional relevant information (e.g., other known triggers of allergy signs)?</p>
																	</td>
																</tr>
																<tr>
																	<td style="height: 10px; line-height: 10px;"></td>
																</tr>
																<tr>
																	<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 100px; padding:0 10px; font-size:14px;">
																		<?php echo isset($serumdata['additional_information']) ? $serumdata['additional_information'] : '';?>
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
					<td width="4%">&nbsp;</td>
					<td width="48%" valign="top">
						<table width="100%">
							<tbody>
								<tr>
									<td width="100%">
										<table width="100%" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="100%" valign="middle">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td style="height: 10px; line-height: 10px;"></td>
																</tr>
																<tr>
																	<td width="100%" valign="top">
																		<p style="color:#346a7e; font-size:14px; line-height: 24px;">Has an elimination food trial been performed with a strict elimination diet?</p>
																	</td>
																</tr>
																<tr>
																	<td style="height: 10px; line-height: 10px;"></td>
																</tr>
																<tr>
																	<td width="100%">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tbody>
																				<tr>
																					<td width="25%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="20%">
																										<?php if( isset($serumdata['elimination_diet']) && (strpos( $serumdata['elimination_diet'], '1' ) !== false) ){ ?> 
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																										<?php }else{ ?>
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																										<?php } ?>	
																									</td>
																									<td width="80%" style="color:#346a7e; font-size:14px;">
																										Yes
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																					<td width="75%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="30%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="20%">
																														<?php if( isset($serumdata['elimination_diet']) && (strpos( $serumdata['elimination_diet'], '2' ) !== false) ){ ?> 
																														<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																														<?php }else{ ?>
																														<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																														<?php } ?>
																													</td>
																													<td width="80%" style="color:#346a7e; font-size:14px;">
																														No
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																									<td width="70%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="100%">
																														<p style="color:#346a7e; font-size:14px; line-height: 24px;">Specify which one(s) if known:</p>
																													</td>
																												</tr>
																												<tr>
																													<td width="100%" style="height:5px; line-height:5px;"></td>
																												</tr>
																												<tr>
																													<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
																														<?php echo isset($serumdata['other_elimination']) ? $serumdata['other_elimination'] : '';?>
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																								</tr>
																							</tbody>	
																						</table>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
																<tr>
																	<td style="height: 10px; line-height: 10px;"></td>
																</tr>
																<tr>
																	<td width="100%" valign="top">
																		<p style="color:#346a7e; font-size:14px; line-height: 24px;">Is the animal receiving any medication at the moment?</p>
																	</td>
																</tr>
																<tr>
																	<td style="height: 10px; line-height: 10px;"></td>
																</tr>
																<tr>
																	<td width="100%">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tbody>
																				<tr>
																					<td width="25%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="20%">
																										<?php if( isset($serumdata['medication']) && (strpos( $serumdata['medication'], '1' ) !== false) ){ ?> 
																										<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																										<?php }else{ ?>
																										<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																										<?php } ?>
																									</td>
																									<td width="80%" style="color:#346a7e; font-size:14px;">
																										Yes
																									</td>
																								</tr>
																							</tbody>
																						</table>
																					</td>
																					<td width="75%">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tbody>
																								<tr>
																									<td width="30%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="20%">
																														<?php if( isset($serumdata['medication']) && (strpos( $serumdata['medication'], '0' ) !== false) ){ ?> 
																														<img class="filled-checkbox" src="<?php echo base_url("/assets/images/filled-checkbox.png"); ?>" alt="NextVu" />
																														<?php }else{ ?>
																														<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																														<?php } ?>
																													</td>
																													<td width="80%" style="color:#346a7e; font-size:14px;">
																														No
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																									<td width="70%">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tbody>
																												<tr>
																													<td width="100%">
																														<p style="color:#346a7e; font-size:14px; line-height: 24px;">Specify which one(s) if known:</p>
																													</td>
																												</tr>
																												<tr>
																													<td width="100%" style="height:5px; line-height:5px;"></td>
																												</tr>
																												<tr>
																													<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 32px; padding:0 10px; font-size:14px;">
																														<?php echo isset($serumdata['medication_desc']) ? $serumdata['medication_desc'] : '';?>
																													</td>
																												</tr>
																											</tbody>
																										</table>
																									</td>
																								</tr>
																							</tbody>	
																						</table>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
																<tr>
																	<td style="height: 10px; line-height: 10px;"></td>
																</tr>
																<tr>
																	<td width="100%" valign="top">
																		<p style="color:#346a7e; font-size:14px; line-height: 24px;">Internal Use Only</p>
																	</td>
																</tr>
																<tr>
																	<td style="height: 10px; line-height: 10px;"></td>
																</tr>
																<tr>
																	<td width="100%" style="background:#ebeff1; border:1px solid #5b8398; outline:none; height: 100px; padding:0 10px; font-size:14px;">
																	</td>
																</tr>
																<tr>
																	<td style="height: 30px; line-height: 30px;"></td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="40" border="0" align="center" width="100%" style="padding: 0mm 8mm;background-color: #e5f2f5;">
			<tbody>
				<tr>
					<td width="100%">
						<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
							<tbody>
								<tr>
									<td width="50%" align="left" valign="middle">
										<table width="100%" cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>
													<td>
														<p style="font-size: 18px;color: #426e89;font-weight: 400; margin: 0;">For allergy resources visit nextmunelaboratories.co.uk</p>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
									<td width="50%" align="right" valign="middle">
										<table cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>
													<td>
														<img src="<?php echo base_url("/assets/images/lock.png"); ?>" height="80" alt="NextVu" />
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="20" border="0" align="center" width="100%" style="padding: 0mm 8mm;background-color: #426e89;">
			<tbody>
				<tr>
					<td width="100%">
						<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
							<tbody>
								<tr>
									<td width="100%" align="center" valign="middle">
										<table width="100%" cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>
													<td>
														<p style="font-size: 24px;color: #fff;font-weight: 400; margin: 0; text-transform: uppercase; text-align: center;">SAMPLE SUBMISSION FORM</p>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
								<tr>
									<td width="100%" style="height: 5px; line-height: 5px;"></td>
								</tr>
								<tr>
									<td width="100%" align="center" valign="middle">
										<table cellpadding="0" cellspacing="0" border="0" width="100%">
											<tbody>
												<tr>
													<td>
														<p style="font-size: 16px;color: #fff;font-weight: 400; margin: 0; text-transform: uppercase; text-align:center;">PLEASE SELECT INDIVIDUAL TEST(S) BY TICKING THE APPROPRIATE BOX(ES)</p>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="padding: 0mm 8mm;">
			<tbody>
				<tr>
					<td width="100%" style="height: 20px; line-height: 20px;"></td>
				</tr>
				<tr>
					<td width="100%">
						<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
							<tbody>
								<tr>
									<td width="35%" align="left" valign="middle">
										<table width="100%" cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>
													<td style="font-size: 20px;color: #426e89;font-weight: 600; margin: 0; text-transform: uppercase;">
														STORAGE ONLY
													</td>
												</tr>
											</tbody>
										</table>
									</td>
									<td width="65%" align="left" valign="top">
										<table cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td width="100%">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tbody>
																				<tr>
																					<td width="7%" valign="top">
																						<img class="blank-checkbox" src="<?php echo base_url("/assets/images/blank-checkbox.png"); ?>" alt="NextVu" />
																					</td>
																					<td valign="top" width="93%" style="color:#346a7e; font-size:14px; text-align: left;">
																						Samples will be held free of charge for 3 months. If you select storage only, please do not tick a test type. Please contact us when you wish to run this sample
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
				<tr>
					<td width="100%" style="height: 40px; line-height: 40px;"></td>
				</tr>
			</tbody>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding: 0 8mm 0 0;">
			<tbody>
				<tr>
					<td width="100%">
						<table width="100%" cellspacing="0" cellpadding="0" border="0">
							<tbody>
								<tr>
									<td width="25%" align="left" valign="top">
										<img src="<?php echo base_url("/assets/images/dog.png"); ?>" width="200" alt="CANINE TEST" />
									</td>
									<td width="75%" align="left" valign="top">
										<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:17px 0 0 0;">
											<tbody>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="50%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td style="background:#cee8ee; color:#426e89; font-size:24px; text-transform: uppercase;">Canine Tests</td>
																			<td style="line-height:0;" valign="top"><img src="<?php echo base_url("/assets/images/tail1.png"); ?>"  height="51" alt="CANINE" /></td>
																		</tr>
																	</table>
																</td>
																<td width="50%">&nbsp;</td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="height: 10px;"></td>
															</tr>
															<tr>
																<td width="100%" style="text-transform: uppercase; font-size: 16px; color:#426e89;"><b>Nextlab</b></td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td valign="top" width="5%">
																				<?php if($ordeType == 'NEXTLAB Complete Environmental Panel (IgE) & Food Panel (IgE & IgG)' && $order_details['species_name'] == 'Dog'){ ?>
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																				<?php }else{ ?>
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<?php } ?>
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">COMPLETE ENVIRONMENTAL & FOOD : Food panel, environmental panel (indoor & outdoor) & Malassezia IgE. Sample required: 2ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																		<tr>
																			<td valign="top" width="5%">
																				<?php if($ordeType == 'NEXTLAB Complete Environmental Panel (IgE)' && $order_details['species_name'] == 'Dog'){ ?>
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																				<?php }else{ ?>
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<?php } ?>
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">ENVIRONMENTAL: Environmental panel (indoor & outdoor) & Malassezia IgE. Sample required: 1ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																		<tr>
																			<td valign="top" width="5%">
																				<?php if($ordeType == 'NEXTLAB Complete Food Panel (IgE & IgG)' && $order_details['species_name'] == 'Dog'){ ?>
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																				<?php }else{ ?>
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<?php } ?>
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">FOOD : Food panel. Sample required: 1ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																	</table>
																</td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="font-size: 11px; color:#000;"><b style="text-transform: uppercase; font-size: 16px; color:#426e89;">Nextlab Screens</b><b>(positive/negative result only; can be expanded on request)</b></td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td valign="top" width="5%">
																				<?php if($ordeType == 'NEXTLAB SCREEN Environmental only, 4 Panels: Grasses, Weeds, Trees and Indoor' && $order_details['species_name'] == 'Dog'){ ?>
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																				<?php }else{ ?>
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<?php } ?>
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">ENVIRONMENTAL SCREEN: Sample required: 1ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																		<tr>
																			<td valign="top" width="5%">
																				<?php if($ordeType == 'NEXTLAB SCREEN Food only, single result Positive/Negative' && $order_details['species_name'] == 'Dog'){ ?>
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																				<?php }else{ ?>
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<?php } ?>
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">FOOD SCREEN: Sample required: 1ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																	</table>
																</td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%"><b style="text-transform: uppercase; font-size: 16px; color:#426e89;">ACUTE PHASE PROTEINS (APPs)</b></td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td valign="top" width="5%">
																				<?php if(preg_match('/\bAcute Phase Proteins\b/', $respnedn->name) && ($order_details['species_name'] == 'Dog')){ ?>
																					<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																				<?php }else{ ?>
																					<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<?php } ?>
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">C-REACTIVE PROTEIN (CRP) Sample required: 0.5ml serum</td>
																		</tr>
																	</table>
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding: 0 8mm 0 0;">
			<tbody>
				<tr>
					<td width="100%" style="height: 5px;"></td>
				</tr>
				<tr>
					<td width="100%">
						<table width="100%" cellspacing="0" cellpadding="0" border="0">
							<tbody>
								<tr>
									<td width="25%" align="left" valign="top">
										<img src="<?php echo base_url("/assets/images/cat.png"); ?>" width="200" alt="Feline TEST" />
									</td>
									<td width="75%" align="left" valign="top">
										<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:27px 0 0 0;">
											<tbody>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="50%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td style="background:#7dc1c9; color:#fff; font-size:24px; text-transform: uppercase;">Feline Tests</td>
																			<td style="line-height:0;" valign="top"><img src="<?php echo base_url("/assets/images/tail2.png"); ?>"  height="51" alt="Feline" /></td>
																		</tr>
																	</table>
																</td>
																<td width="50%">&nbsp;</td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="height: 10px;"></td>
															</tr>
															<tr>
																<td width="100%" style="text-transform: uppercase; font-size: 16px; color:#426e89;"><b>Nextlab</b></td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td valign="top" width="5%">
																				<?php if($ordeType == 'NEXTLAB Complete Environmental Panel (IgE) & Food Panel (IgE & IgG)' && $order_details['species_name'] == 'Cat'){ ?>
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																				<?php }else{ ?>
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<?php } ?>
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">COMPLETE ENVIRONMENTAL & FOOD: Food panel, environmental panel (indoor & outdoor). Sample required: 2ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																		<tr>
																			<td valign="top" width="5%">
																				<?php if($ordeType == 'NEXTLAB Complete Environmental Panel (IgE)' && $order_details['species_name'] == 'Cat'){ ?>
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																				<?php }else{ ?>
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<?php } ?>
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">ENVIRONMENTAL: Environmental panel (indoor & outdoor). Sample required: 1ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																		<tr>
																			<td valign="top" width="5%">
																				<?php if($ordeType == 'NEXTLAB Complete Food Panel (IgE & IgG)' && $order_details['species_name'] == 'Cat'){ ?>
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																				<?php }else{ ?>
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<?php } ?>
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">FOOD : Food panel. Sample required: 1ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																	</table>
																</td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="font-size: 11px; color:#000;"><b style="text-transform: uppercase; font-size: 16px; color:#426e89;">Nextlab Screens</b><b>(positive/negative result only; can be expanded on request)</b></td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td valign="top" width="5%">
																				<?php if($ordeType == 'NEXTLAB SCREEN Environmental only, 4 Panels: Grasses, Weeds, Trees and Indoor' && $order_details['species_name'] == 'Cat'){ ?>
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																				<?php }else{ ?>
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<?php } ?>
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">ENVIRONMENTAL SCREEN: Sample required: 1ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																		<tr>
																			<td valign="top" width="5%">
																				<?php if($ordeType == 'NEXTLAB SCREEN Food only, single result Positive/Negative' && $order_details['species_name'] == 'Cat'){ ?>
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																				<?php }else{ ?>
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<?php } ?>
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">FOOD SCREEN: Sample required: 1ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																	</table>
																</td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%"><b style="text-transform: uppercase; font-size: 16px; color:#426e89;">ACUTE PHASE PROTEINS (APPs)</b></td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td valign="top" width="5%">
																				<?php if(preg_match('/\bAcute Phase Proteins\b/', $respnedn->name) && ($order_details['species_name'] == 'Cat')){ ?>
																					<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																				<?php }else{ ?>
																					<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<?php } ?>
																			</td>
																			<td valign="top" width="95%" style="font-size: 11px; line-height: 16px; color:#000;">α1-ACID GLYCOPROTEIN (AGP): Sample required: 0.5ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																	</table>
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding: 0 8mm 0 0;">
			<tbody>
				<tr>
					<td width="100%">
						<table width="100%" cellspacing="0" cellpadding="0" border="0">
							<tbody>
								<tr>
									<td width="25%" align="left" valign="top">
										<img src="<?php echo base_url("/assets/images/horse.png"); ?>" width="200" alt="Equine TEST" />
									</td>
									<td width="75%" align="left" valign="top">
										<table width="100%" cellspacing="0" cellpadding="0" border="0" style="padding:17px 0 0 0;">
											<tbody>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="50%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td style="background:#b8c6d6; color:#426e89; font-size:24px; text-transform: uppercase;">Equine Tests</td>
																			<td style="line-height:0;" valign="top"><img src="<?php echo base_url("/assets/images/tail3.png"); ?>"  height="51" alt="Equine" /></td>
																		</tr>
																	</table>
																</td>
																<td width="50%">&nbsp;</td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="height: 10px;"></td>
															</tr>
															<tr>
																<td width="100%" style="text-transform: uppercase; font-size: 16px; color:#426e89;"><b>Nextlab</b></td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td valign="top" width="5%">
																				<?php if($ordeType == 'NEXTLAB Complete Environmental and Insect Panel (IgE) & Food (IgE & IgG)' && $order_details['species_name'] == 'Horse'){ ?>
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																				<?php }else{ ?>
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<?php } ?>
																			</td>
																			<td valign="top" width="95%" style="font-size: 12px; line-height: 16px; color:#000;">COMPLETE ENVIRONMENTAL, INSECT & FOOD: Food panel, environmental panel (indoor & outdoor) and insect panel. Sample required: 3ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																		<tr>
																			<td valign="top" width="5%">
																				<?php if($ordeType == 'NEXTLAB Complete Environmental and Insect Panel (IgE)' && $order_details['species_name'] == 'Horse'){ ?>
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																				<?php }else{ ?>
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<?php } ?>
																			</td>
																			<td valign="top" width="95%" style="font-size: 12px; line-height: 16px; color:#000;">ENVIRONMENTAL & INSECT: Environmental panel (indoor & outdoor) & insect panel. Sample required: 2ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																		<tr>
																			<td valign="top" width="5%">
																				<?php if($ordeType == 'NEXTLAB Complete Food (IgE & IgG)' && $order_details['species_name'] == 'Horse'){ ?>
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																				<?php }else{ ?>
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<?php } ?>
																			</td>
																			<td valign="top" width="95%" style="font-size: 12px; line-height: 16px; color:#000;">FOOD: Food panel. Sample required: 1ml serum</td>
																		</tr>
																		<tr>
																			<td style="height: 5px;"></td>
																		</tr>
																	</table>
																</td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="font-size: 11px; color:#000;"><b style="text-transform: uppercase; font-size: 16px; color:#426e89;">Nextlab Screens</b><b>(positive/negative result only; can be expanded on request)</b></td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%">
														<table width="100%" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" style="height: 5px;"></td>
															</tr>
															<tr>
																<td width="100%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td valign="top" width="5%">
																				<?php if($ordeType == 'NEXTLAB SCREEN Environmental & Insect Screen (IgE)' && $order_details['species_name'] == 'Horse'){ ?>
																				<img class="filled-checkbox" src="<?php echo base_url("/assets/images/serum-filled-checkbox.png"); ?>" alt="NextVu" />
																				<?php }else{ ?>
																				<img class="blank-checkbox" src="<?php echo base_url("/assets/images/serum-blank-checkbox.png"); ?>" alt="NextVu" />
																				<?php } ?>
																			</td>
																			<td valign="top" width="95%" style="font-size: 12px; line-height: 16px; color:#000;">ENVIRONMENTAL & INSECT SCREEN: Sample required: 2ml serum</td>
																		</tr>
																	</table>
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<div style='page-break-after:always'></div>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="padding:5mm 8mm;">
			<tbody>
				<tr>
					<td width="100%">
						<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
							<tbody>
								<tr>
									<td width="100%">
										<table cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>
													<td style="color: #333333; font-size:12px;">Samples submitted are subject to Nextmune Laboratories’ terms & conditions of business (www.nextmunelaboratories.co.uk/terms-of-business)</td>
												</tr>
												<tr>
													<td style="height: 20px; line-height: 20px;"></td>
												</tr>
												<tr>
													<td style="color: #333333; font-size:12px;">We may store and use any surplus serum for quality control, research and development purposes.</td>
												</tr>
												<tr>
													<td style="height: 5px; line-height: 5px;"></td>
												</tr>
												<tr>
													<td style="color: #333333; font-size:12px;">If you do not wish Nextmune Laboratories to utilise this sample, please tick here</td>
												</tr>
												<tr>
													<td style="height: 10px; line-height: 10px;"></td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
			<tbody>
				<tr>
					<td style="height: 25px;"></td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="padding: 0mm 8mm;background-color: #426e89;">
			<tbody>
				<tr>
					<td width="100%">
						<table class="header" cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
							<tbody>
								<tr>
									<td width="100%" align="center" valign="middle">
										<table width="100%" cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>
													<td>
														<p style="font-size: 13px;color: #fff;font-weight: 400; margin: 0; text-align: center;">Nextmune Laboratories Limited, Unit 651, Street 5, Thorp Arch Trading Estate, Wetherby, UK, LS23 7FZ</p>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
								<tr>
									<td width="100%" style="height: 5px; line-height: 5px;"></td>
								</tr>
								<tr>
									<td width="100%" align="center" valign="middle">
										<table cellpadding="0" cellspacing="0" border="0" width="100%">
											<tbody>
												<tr>
													<td>
														<p style="font-size: 13px;color: #fff;font-weight: 400; margin: 0; text-align: center;"> T – 0800 3 047 047 E – <a href="mailto:vetorders.uk@nextmune.com" style="color: #fff; text-decoration: underline;">vetorders.uk@nextmune.com</a></p>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="padding: 0mm 8mm;">
			<tbody>
				<tr>
					<td width="100%">
						<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%">
							<tbody>
								<tr>
									<td width="50%" align="left" valign="middle">
										<table width="100%" cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>
													<td>
														<p style="font-size: 12px;color: #333333;font-weight: 700; margin: 0;">© 2022 Nextmune Laboratories Limited</p>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
									<td width="50%" align="right" valign="middle">
										<table cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>
													<td>
														<p style="font-size: 12px;color: #333333;font-weight: 700; margin: 0;">NM035_06_22</p>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
	</body>
</html>