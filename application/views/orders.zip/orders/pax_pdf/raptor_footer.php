<table style="width:100%;">
	<tbody>
		<tr><td width="30%" align="left" style="font-size:11px;text-align:left;padding-left: 40px;">
			<!-- <img src="assets/images/Extract.png" alt="Allergen Extract" style="width: 18px;">&nbsp;&nbsp;&nbsp; Allergen Extract --></td>
			<td width="60%" align="left" style="font-size:11px;text-align:left;">
			<!-- <img src="assets/images/Molecular.png" alt="Molecular Allergen	" style="width: 18px;">&nbsp;&nbsp;&nbsp; Molecular Allergen --></td>
			<td width="10%" style="background:url(assets/images/footer_page.png) center top no-repeat #ffffff;text-align:right;border-radius: 40px 0px 0px 40px;height: 100%;background-size: cover;background-repeat: repeat-x;background-position-y: center;color: #ffffff;font-weight: bold;text-align: center; padding: 10px; vertical-align: middle; ">{PAGENO}</td>
		</tr>
	</tbody>
</table> 