<!DOCTYPE html>
<html class="js">
	<head>
		<title>Serum Test Request Form</title>
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
		<style>
		*{font-family: 'Open Sans', sans-serif; box-sizing:border-box;}
		.header th{text-align:left;}
		</style>
	</head>
	<body bgcolor="#cccccc">
		<?php 
		if($order_details['pet_id']>0){
			$this->db->select('type,breed_id,other_breed,gender,age,age_year');
			$this->db->from('ci_pets');
			$this->db->where('id', $order_details['pet_id']);
			$petinfo = $this->db->get()->row_array();

			if($petinfo['breed_id']>0){
				$this->db->select('name');
				$this->db->from('ci_breeds');
				$this->db->where('id', $petinfo['breed_id']);
				$breedinfo = $this->db->get()->row_array();
			}else{
				$breedinfo = array();
			}
		}else{
			$petinfo = array();
			$breedinfo = array();
		}

		if($order_details['vet_user_id']>0){
			$refDatas = $this->UsersDetailsModel->getColumnAllArray($order_details['vet_user_id']);
			$refDatas = array_column($refDatas, 'column_field', 'column_name');
			$add_1 = !empty($refDatas['add_1']) ? $refDatas['add_1'].', ' : '';
			$add_2 = !empty($refDatas['add_2']) ? $refDatas['add_2'].', ' : '';
			$add_3 = !empty($refDatas['add_3']) ? $refDatas['add_3'] : '';
			$city = !empty($refDatas['add_4']) ? $refDatas['add_4'] : '';
			$postcode = !empty($refDatas['address_3']) ? $refDatas['address_3'] : '';
			$fulladdress = $add_1.$add_2.$add_3;
		}else{
			$fulladdress = '';
			$city = '';
			$postcode = '';
		}

		if(!empty($order_details['product_code_selection'])){
			$this->db->select('name');
			$this->db->from('ci_price');
			$this->db->where('id', $order_details['product_code_selection']);
			$ordeType = $this->db->get()->row()->name;
		}else{
			$ordeType = 'Serum Testing';
		}
		$serumdata = $this->OrdersModel->getSerumTestRecord($order_details['id']);
		$years = !empty($petinfo['age_year'])?$petinfo['age_year'].'Year, ':'';
		$months = !empty($petinfo['age'])?$petinfo['age'].'Month':'';
		?>
		<table class="main_container" cellspacing="0" cellpadding="0" border="0" align="center" width="935px" style="width:935px; max-width:935px; padding:0; background:#ffffff;border: none;">
			<tbody>
				<tr>
					<td>
						<table class="header" cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="width:100%;padding-right:20px;">
							<tbody>
								<tr>
									<td valign="middle" width="350" style="background:#426e89; padding:40px 10px 40px 30px;">
										<h4 style="font-size: 40px;text-transform: uppercase;color: #ffffff;font-weight: 400;margin: 0;letter-spacing: 2px;line-height: 52px; white-space:nowrap;">SERUM TEST<br> REQUEST FORM</h4>
									</td>
									<td valign="top" style="line-height:0;">
										<img src="<?php echo base_url("/assets/images/aqua-corner.png"); ?>" alt="NextVu" height="200" />
									</td>
							
									<td style="line-height:0; padding:0 10px 0 30px;" align="right">
										<img src="<?php echo base_url("/assets/images/nextmune-uk.png"); ?>" height="65" alt="NextVu" />
									</td>
								</tr>
							</tbody>
						</table>
						<table class="" cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="width:100%; padding:0 15px;">
							<tbody>
								<tr><td height="40"><p style="color: #346a7e;font-size:16px;"><b>Order Type:</b> <?php echo $ordeType; ?></p></td></tr>
								<tr>
									<td colspan="3">
										<h5 style="color:#426e89; letter-spacing:1px; margin:0 0 20px 0; padding:0; font-size:24px; font-weight:400;">Practice details</h5>
									</td>
								</tr>
								<tr>
									<td>
										<table width="48%" align="left" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="28%;">
														<label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">Date:</label>
														<input type="text" value="<?php echo date('d/m/Y',strtotime($order_details['order_date'])); ?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:32px; padding:0 10px;" />
													</td>
													<td width="2%"></td>
													<td width="50%;">
														<label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">Veterinary surgeon:</label>
														<input type="text" value="<?php echo $order_details['name']; ?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:32px; padding:0 10px;" />
													</td>
												</tr>
												<tr><td height="10"></td></tr>
												<tr>
													<td width="100%;" colspan="3">
														<label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">Veterinary practice:</label>
														<input type="text" value="<?php echo $order_details['practice_name']; ?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:32px; padding:0 10px;" />
													</td>
												</tr>
												<tr><td height="10"></td></tr>
												<tr>
													<td width="100%;" colspan="3">
														<label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">Practice details:</label>
														<input type="text" value="<?php echo $fulladdress; ?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:32px; padding:0 10px;" />
													</td>
												</tr>
												<tr><td height="10"></td></tr>
												<tr>
													<td width="48%;">
														<label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">City:</label>
														<input type="text" value="<?php echo $city; ?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:32px; padding:0 10px;" />
													</td>
													<td width="2%"></td>
													<td width="32%;">
														<label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">Postcode:</label>
														<input type="text" value="<?php echo $postcode; ?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:32px; padding:0 10px;" />
													</td>
												</tr>
											</tbody>
										</table>
										<table width="48%" align="right" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="100%;" colspan="3">
														<label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">Phone:</label>
														<input type="text" value="<?php echo $order_details['phone_number']; ?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:32px; padding:0 10px;" />
													</td>
												</tr>
												<tr><td height="10"></td></tr>
												<tr>
													<td width="100%;" colspan="3">
														<label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">Email:</label>
														<input type="text" value="<?php echo $order_details['email']; ?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:32px; padding:0 10px;" />
													</td>
												</tr>
												<tr><td height="10"></td></tr>
												<tr>
													<td width="100%;" colspan="3">
														<label style="display:block; color:#346a7e; font-size:14px;">Results will be delivered by email.</label>
													</td>
												</tr>
												<tr><td height="10"></td></tr>
												<tr>
													<td width="100%;" colspan="3">
														<label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if($order_details['shipping_materials'] == '1'){ echo 'checked="checked"'; } ?> /> I would like to order more serum test shipping materials</label>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
						<table class="" cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="width:100%; padding:0 15px;">
							<tbody>
								<tr><td height="40"></td></tr>
								<tr>
									<td colspan="3">
										<h5 style="color:#426e89; letter-spacing:1px; margin:0 0 20px 0; padding:0; font-size:24px; font-weight:400;">Pet and pet owner details</h5>
									</td>
								</tr>
								<tr>
									<td>
										<table width="48%" align="left" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="48%;">
														<label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">Pet owner’s first name:</label>
														<input type="text" value="<?php echo $order_details['pet_owner_name']; ?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:32px; padding:0 10px;" />
													</td>
													<td width="2%"></td>
													<td width="50%;">
														<label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">Pet owners last name:</label>
														<input type="text" value="<?php echo $order_details['po_last']; ?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:32px; padding:0 10px;" />
													</td>
												</tr>
												<tr><td height="10"></td></tr>
												<tr>
													<td><label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">Species:</label></td>
												</tr>
												<tr>
													<td width="100%;" colspan="3">
														<table cellspacing="0" cellpadding="0" border="0" width="100%">
															<tbody>
																<tr>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if($order_details['species_name'] == 'Dog'){ echo 'checked="checked"'; } ?> /> Dog</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if($order_details['species_name'] == 'Cat'){ echo 'checked="checked"'; } ?> /> Cat</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if($order_details['species_name'] == 'Horse'){ echo 'checked="checked"'; } ?> /> Horse</label></td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr><td height="10"></td></tr>
												<tr>
													<td width="48%;">
														<label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">Breed:</label>
														<input type="text" value="<?php echo $breedinfo['name']; ?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:30px; padding:0 10px;" />
													</td>
													<td width="2%"></td>
													<td width="50%;">
														<label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">Age Month and Year:</label>
														<input type="text" value="<?php echo $years.$months; ?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:30px; padding:0 10px;" />
													</td>
												</tr>
											</tbody>
										</table>
										<table width="48%" align="right" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="100%;" colspan="3">
														<label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">Animal name:</label>
														<input type="text" value="<?php echo $order_details['pet_name']; ?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:30px; padding:0 10px;" />
													</td>
												</tr>
												<tr><td height="10"></td></tr>
												<tr>
													<td><label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">Gender:</label></td>
												</tr>
												<tr>
													<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if($petinfo['gender'] == '1'){ echo 'checked="checked"'; } ?> /> Male</label></td>
													<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if($petinfo['gender'] == '2'){ echo 'checked="checked"'; } ?> /> Female</label></td>
													<td></td>
												</tr>
												<tr><td height="10"></td></tr>
												<tr>
													<td width="100%;" colspan="3">
														<label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">Date serum drawn:</label>
														<input type="text" value="<?php echo !empty($serumdata['serum_drawn_date'])?date('d/m/Y',strtotime($serumdata['serum_drawn_date'])):''; ?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:30px; padding:0 10px;" />
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
						<table class="" cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="width:100%; padding:0 15px;">
							<tbody>
								<tr><td height="40"></td></tr>
								<tr>
									<td colspan="3">
										<h5 style="color:#426e89; letter-spacing:1px; margin:0 0 20px 0; padding:0; font-size:24px; font-weight:400;">Medical history</h5>
									</td>
								</tr>
							</tbody>
						</table>
						<table class="" cellspacing="0" cellpadding="0" border="0" align="center" width="100%" style="width:100%; padding:0 15px">
							<tbody>
								<tr>
									<td>
										<table width="100%" align="left" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td><label style="display:block; color:#346a7e; font-size:14px;">With which one(s) of the following is the patient affected?</label></td>
												</tr>
												<tr><td height="10"></td></tr>
												<tr>
													<td>
														<table cellspacing="0" cellpadding="0" border="0" width="100%">
															<tbody>
																<tr>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['major_symptoms']) && (strpos( $serumdata['major_symptoms'], '1' ) !== false) ){ echo 'checked'; } ?> /> Pruritus (itch)</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['major_symptoms']) && (strpos( $serumdata['major_symptoms'], '5' ) !== false) ){ echo 'checked'; } ?> /> Skin lesions</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['major_symptoms']) && (strpos( $serumdata['major_symptoms'], '2' ) !== false) ){ echo 'checked'; } ?> /> Otitis</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['major_symptoms']) && (strpos( $serumdata['major_symptoms'], '3' ) !== false) ){ echo 'checked'; } ?> /> Respiratory signs</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['major_symptoms']) && (strpos( $serumdata['major_symptoms'], '6' ) !== false) ){ echo 'checked'; } ?> /> Ocular signs</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['major_symptoms']) && (strpos( $serumdata['major_symptoms'], '7' ) !== false) ){ echo 'checked'; } ?> /> Anaphylaxis</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['major_symptoms']) && (strpos( $serumdata['major_symptoms'], '4' ) !== false) ){ echo 'checked'; } ?> /> Gastro-intestinal signs</label></td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr><td height="10"></td></tr>
												<tr>
													<td>
														<table width="48%" align="left" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr><td height="20"></td></tr>
																<tr>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['major_symptoms']) && (strpos( $serumdata['major_symptoms'], '0' ) !== false) ){ echo 'checked'; } ?> /> Other</label></td>
																	<td><input type="text" value="<?php echo isset($serumdata['other_symptom']) ? $serumdata['other_symptom'] : ''; ?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:32px; padding:0 10px;" /></td>
																</tr>
															</tbody>
														</table>
														<table width="48%" align="right" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td>
																		<label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">At what age did these symptoms first appear?</label>
																		<input type="text" value="<?php echo $serumdata['symptom_appear_age'].' years '.$serumdata['symptom_appear_age_month'].' months'; ?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:30px; padding:0 10px;" />
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
										<table width="100%"><tbody><tr><td height="10"></td></tr></tbody></table>
										<table width="48%" align="left" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="100%;" colspan="3">
														<table cellspacing="0" cellpadding="0" border="0" width="100%">
															<tbody>
																<tr>
																	<td colspan="5"><label style="display:block; color:#346a7e; font-size:14px;">When are the symptoms most obvious?</label></td>
																</tr>
																<tr><td height="10"></td></tr>
																<tr>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['when_obvious_symptoms']) && (strpos( $serumdata['when_obvious_symptoms'], '1' ) !== false) ){ echo 'checked'; } ?> /> Spring</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['when_obvious_symptoms']) && (strpos( $serumdata['when_obvious_symptoms'], '2' ) !== false) ){ echo 'checked'; } ?> /> Summer</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['when_obvious_symptoms']) && (strpos( $serumdata['when_obvious_symptoms'], '3' ) !== false) ){ echo 'checked'; } ?> /> Fall</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['when_obvious_symptoms']) && (strpos( $serumdata['when_obvious_symptoms'], '4' ) !== false) ){ echo 'checked'; } ?> /> Winter</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['when_obvious_symptoms']) && (strpos( $serumdata['when_obvious_symptoms'], '5' ) !== false) ){ echo 'checked'; } ?> /> Year-round</label></td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr><td height="10"></td></tr>
												<tr>
													<td width="100%;" colspan="3">
														<table cellspacing="0" cellpadding="0" border="0" width="100%">
															<tbody>
																<tr>
																	<td colspan="5"><label style="display:block; color:#346a7e; font-size:14px;">Has there been a clinical diagnosis of allergy to the following?</label></td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr><td height="10"></td></tr>
												<tr>
													<td width="100%;" colspan="3">
														<table cellspacing="0" cellpadding="0" border="0" width="100%">
															<tbody>
																<tr>
																	<td colspan="5"><label style="display:block; color:#346a7e; font-size:14px;">Food(s):</label></td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%;" colspan="3">
														<table cellspacing="0" cellpadding="0" border="0" width="100%">
															<tbody>
																<tr>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['diagnosis_food']) && (strpos( $serumdata['diagnosis_food'], '1' ) !== false) ){ echo 'checked'; } ?> /> Yes</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['diagnosis_food']) && (strpos( $serumdata['diagnosis_food'], '2' ) !== false) ){ echo 'checked'; } ?> /> No</label></td>
																	<td colspan="3">
																		<label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">Specify which one(s) if known:</label>
																		<input type="text" value="<?php echo isset($serumdata['other_diagnosis_food']) ? $serumdata['other_diagnosis_food'] : '';?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:32px; padding:0 10px;">
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr><td height="10"></td></tr>
												<tr>
													<td width="100%;" colspan="3">
														<table cellspacing="0" cellpadding="0" border="0" width="100%">
															<tbody>
																<tr>
																	<td colspan="5"><label style="display:block; color:#346a7e; font-size:14px;">Hymenoptera stings:</label></td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%;" colspan="3">
														<table cellspacing="0" cellpadding="0" border="0" width="100%">
															<tbody>
																<tr>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['diagnosis_hymenoptera']) && (strpos( $serumdata['diagnosis_hymenoptera'], '1' ) !== false) ){ echo 'checked'; } ?> /> Yes</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['diagnosis_hymenoptera']) && (strpos( $serumdata['diagnosis_hymenoptera'], '2' ) !== false) ){ echo 'checked'; } ?> /> No</label></td>
																	<td colspan="3">
																		<label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">Specify which one(s) if known:</label>
																		<input type="text" value="<?php echo isset($serumdata['other_diagnosis_hymenoptera']) ? $serumdata['other_diagnosis_hymenoptera'] : '';?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:32px; padding:0 10px;">
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
										<table width="48%" align="right" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="100%;" colspan="3">
														<table cellspacing="0" cellpadding="0" border="0" width="100%">
															<tbody>
																<tr>
																	<td colspan="5"><label style="display:block; color:#346a7e; font-size:14px;">Where are the symptoms most obvious?</label></td>
																</tr>
																<tr><td height="10"></td></tr>
																<tr>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['where_obvious_symptoms']) && (strpos( $serumdata['where_obvious_symptoms'], '1' ) !== false) ){ echo 'checked'; } ?> /> Indoors</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['where_obvious_symptoms']) && (strpos( $serumdata['where_obvious_symptoms'], '2' ) !== false) ){ echo 'checked'; } ?> /> Outdoors</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['where_obvious_symptoms']) && (strpos( $serumdata['where_obvious_symptoms'], '3' ) !== false) ){ echo 'checked'; } ?> /> No Difference</label></td>
																	<td></td>
																	<td></td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr><td height="50"></td></tr>
												<tr>
													<td width="100%;" colspan="3">
														<table cellspacing="0" cellpadding="0" border="0" width="100%">
															<tbody>
																<tr>
																	<td colspan="5"><label style="display:block; color:#346a7e; font-size:14px;">How fast do signs relapse after a food challenge:</label></td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr><td height="15"></td></tr>
												<tr>
													<td width="100%;" colspan="3">
														<table cellspacing="0" cellpadding="0" border="0" width="100%">
															<tbody>
																<tr>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['food_challenge']) && (strpos( $serumdata['food_challenge'], '1' ) !== false) ){ echo 'checked'; } ?> />  &lt; 3 h</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['food_challenge']) && (strpos( $serumdata['food_challenge'], '2' ) !== false) ){ echo 'checked'; } ?> /> 3-12 h</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['food_challenge']) && (strpos( $serumdata['food_challenge'], '3' ) !== false) ){ echo 'checked'; } ?> /> 12-24 h</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['food_challenge']) && (strpos( $serumdata['food_challenge'], '4' ) !== false) ){ echo 'checked'; } ?> /> 24-48 h</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['food_challenge']) && (strpos( $serumdata['food_challenge'], '5' ) !== false) ){ echo 'checked'; } ?> /> &gt; 48 h</label></td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr><td height="15"></td></tr>
												<tr>
													<td width="100%;" colspan="3">
														<table cellspacing="0" cellpadding="0" border="0" width="100%">
															<tbody>
																<tr>
																	<td colspan="5"><label style="display:block; color:#346a7e; font-size:14px;">Other(s):</label></td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr>
													<td width="100%;" colspan="3">
														<table cellspacing="0" cellpadding="0" border="0" width="100%">
															<tbody>
																<tr>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['diagnosis_other']) && (strpos( $serumdata['diagnosis_other'], '1' ) !== false) ){ echo 'checked'; } ?> /> Yes</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['diagnosis_other']) && (strpos( $serumdata['diagnosis_other'], '2' ) !== false) ){ echo 'checked'; } ?> /> No</label></td>
																	<td colspan="3">
																		<label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">Specify which one(s) if known:</label>
																		<input type="text" value="<?php echo isset($serumdata['other_diagnosis']) ? $serumdata['other_diagnosis'] : '';?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:32px; padding:0 10px;">
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
										<table width="100%"><tbody><tr><td height="10"></td></tr></tbody></table>
										<table width="100%" align="left" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td><label style="display:block; color:#346a7e; font-size:14px;">Is the patient regularly exposed to the following animals:</label></td>
												</tr>
												<tr><td height="10"></td></tr>
												<tr>
													<td>
														<table cellspacing="0" cellpadding="0" border="0" width="100%">
															<tbody>
																<tr>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['regularly_exposed']) && (strpos( $serumdata['regularly_exposed'], '1' ) !== false) ){ echo 'checked'; } ?> /> Cats</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['regularly_exposed']) && (strpos( $serumdata['regularly_exposed'], '2' ) !== false) ){ echo 'checked'; } ?> /> Dogs</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['regularly_exposed']) && (strpos( $serumdata['regularly_exposed'], '3' ) !== false) ){ echo 'checked'; } ?> /> Horses</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['regularly_exposed']) && (strpos( $serumdata['regularly_exposed'], '4' ) !== false) ){ echo 'checked'; } ?> /> Cattle</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['regularly_exposed']) && (strpos( $serumdata['regularly_exposed'], '5' ) !== false) ){ echo 'checked'; } ?> /> Mice</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['regularly_exposed']) && (strpos( $serumdata['regularly_exposed'], '6' ) !== false) ){ echo 'checked'; } ?> /> Guinea pigs</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['regularly_exposed']) && (strpos( $serumdata['regularly_exposed'], '7' ) !== false) ){ echo 'checked'; } ?> /> Rabbits</label></td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr><td height="10"></td></tr>
												<tr>
													<td>
														<table width="48%" align="left" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr><td height="20"></td></tr>
																<tr>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['regularly_exposed']) && (strpos( $serumdata['regularly_exposed'], '0' ) !== false) ){ echo 'checked'; } ?> /> Other(s)</label></td>
																	<td><input type="text" value="<?php echo isset($serumdata['other_exposed']) ? $serumdata['other_exposed'] : ''; ?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:32px; padding:0 10px;" /></td>
																</tr>
															</tbody>
														</table>
														<table width="48%" align="right" cellspacing="0" cellpadding="0" border="0">
															<tbody>
																<tr>
																	<td width="100%;" colspan="3">
																		<table cellspacing="0" cellpadding="0" border="0" width="100%">
																			<tbody>
																				<tr>
																					<td colspan="5"><label style="display:block; color:#346a7e; font-size:14px;">Does the patient suffer from recurrent Malassezia infections?</label></td>
																				</tr>
																				<tr><td height="10"></td></tr>
																				<tr>
																					<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['malassezia_infections']) && (strpos( $serumdata['malassezia_infections'], '1' ) !== false) ){ echo 'checked'; } ?> /> Malassezia otitis</label></td>
																					<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['malassezia_infections']) && (strpos( $serumdata['malassezia_infections'], '2' ) !== false) ){ echo 'checked'; } ?> /> Malassezia dermatitis</label></td>
																					<td></td>
																					<td></td>
																					<td></td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
										<table width="100%"><tbody><tr><td height="10"></td></tr></tbody></table>
										<table width="100%" align="left" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="100%;" colspan="3">
														<table cellspacing="0" cellpadding="0" border="0" width="100%">
															<tbody>
																<tr>
																	<td colspan="5"><label style="display:block; color:#346a7e; font-size:14px;">Is the patient receiving the following drugs and what was the response to treatment?</label></td>
																</tr>
																<tr><td height="10"></td></tr>
																<tr>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs']) && (strpos( $serumdata['receiving_drugs'], '1' ) !== false) ){ echo 'checked'; } ?> /> Glucocorticoids (oral, topical, injectable)</label></td>
																	<td></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs_1']) && (strpos( $serumdata['receiving_drugs_1'], '1' ) !== false) ){ echo 'checked'; } ?> /> No response</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs_1']) && (strpos( $serumdata['receiving_drugs_1'], '2' ) !== false) ){ echo 'checked'; } ?> /> Fair response</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs_1']) && (strpos( $serumdata['receiving_drugs_1'], '3' ) !== false) ){ echo 'checked'; } ?> /> Good to excellent response</label></td>
																</tr>
																<tr><td height="10"></td></tr>
																<tr>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs']) && (strpos( $serumdata['receiving_drugs'], '2' ) !== false) ){ echo 'checked'; } ?> /> Ciclosporin</label></td>
																	<td></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs_2']) && (strpos( $serumdata['receiving_drugs_2'], '1' ) !== false) ){ echo 'checked'; } ?> /> No response</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs_2']) && (strpos( $serumdata['receiving_drugs_2'], '2' ) !== false) ){ echo 'checked'; } ?> /> Fair response</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs_2']) && (strpos( $serumdata['receiving_drugs_2'], '3' ) !== false) ){ echo 'checked'; } ?> /> Good to excellent response</label></td>
																</tr>
																<tr><td height="10"></td></tr>
																<tr>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs']) && (strpos( $serumdata['receiving_drugs'], '3' ) !== false) ){ echo 'checked'; } ?> /> Oclacitinib</label></td>
																	<td></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs_3']) && (strpos( $serumdata['receiving_drugs_3'], '1' ) !== false) ){ echo 'checked'; } ?> /> No response</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs_3']) && (strpos( $serumdata['receiving_drugs_3'], '2' ) !== false) ){ echo 'checked'; } ?> /> Fair response</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs_3']) && (strpos( $serumdata['receiving_drugs_3'], '3' ) !== false) ){ echo 'checked'; } ?> /> Good to excellent response</label></td>
																</tr>
																<tr><td height="10"></td></tr>
																<tr>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs']) && (strpos( $serumdata['receiving_drugs'], '4' ) !== false) ){ echo 'checked'; } ?> /> Lokivetmab</label></td>
																	<td></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs_4']) && (strpos( $serumdata['receiving_drugs_4'], '1' ) !== false) ){ echo 'checked'; } ?> /> No response</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs_4']) && (strpos( $serumdata['receiving_drugs_4'], '2' ) !== false) ){ echo 'checked'; } ?> /> Fair response</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs_4']) && (strpos( $serumdata['receiving_drugs_4'], '3' ) !== false) ){ echo 'checked'; } ?> /> Good to excellent response</label></td>
																</tr>
																<tr><td height="10"></td></tr>
																<tr>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs']) && (strpos( $serumdata['receiving_drugs'], '5' ) !== false) ){ echo 'checked'; } ?> /> Antibiotics</label></td>
																	<td></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs_5']) && (strpos( $serumdata['receiving_drugs_5'], '1' ) !== false) ){ echo 'checked'; } ?> /> No response</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs_5']) && (strpos( $serumdata['receiving_drugs_5'], '2' ) !== false) ){ echo 'checked'; } ?> /> Fair response</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs_5']) && (strpos( $serumdata['receiving_drugs_5'], '3' ) !== false) ){ echo 'checked'; } ?> /> Good to excellent response</label></td>
																</tr>
																<tr><td height="10"></td></tr>
																<tr>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="checkbox" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs']) && (strpos( $serumdata['receiving_drugs'], '6' ) !== false) ){ echo 'checked'; } ?> /> Antifungals</label></td>
																	<td></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs_6']) && (strpos( $serumdata['receiving_drugs_6'], '1' ) !== false) ){ echo 'checked'; } ?> /> No response</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs_6']) && (strpos( $serumdata['receiving_drugs_6'], '2' ) !== false) ){ echo 'checked'; } ?> /> Fair response</label></td>
																	<td><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php if( isset($serumdata['receiving_drugs_6']) && (strpos( $serumdata['receiving_drugs_6'], '3' ) !== false) ){ echo 'checked'; } ?> /> Good to excellent response</label></td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
										<table width="100%"><tbody><tr><td height="10"></td></tr></tbody></table>
										<table width="48%" align="left" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="100%;" colspan="3">
														<table cellspacing="0" cellpadding="0" border="0" width="100%">
															<tbody>
																<tr>
																	<td colspan="5"><label style="display:block; color:#346a7e; font-size:14px;">Did the patient receive or is receiving treatment against ectoparasites?</label></td>
																</tr>
																<tr><td height="10"></td></tr>
																<tr>
																	<td width="20%"><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php echo ( isset($serumdata['treatment_ectoparasites']) && $serumdata['treatment_ectoparasites']==1) ? 'checked' : ''; ?> /> Yes</label></td>
																	<td width="20%"><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php echo ( isset($serumdata['treatment_ectoparasites']) && $serumdata['treatment_ectoparasites']==2) ? 'checked' : ''; ?> /> No</label></td>
																	<td width="60%" colspan="3">
																		<label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">Specify which one(s) if known:</label>
																		<input type="text" value="<?php echo isset($serumdata['other_ectoparasites']) ? $serumdata['other_ectoparasites'] : '';?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:32px; padding:0 10px;">
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr><td height="10"></td></tr>
												<tr>
													<td width="100%;" colspan="3">
														<table cellspacing="0" cellpadding="0" border="0" width="100%">
															<tbody>
																<tr>
																	<td colspan="5"><label style="display:block; color:#346a7e; font-size:14px;">Is this animal suffering from a zoonotic disease?</label></td>
																</tr>
																<tr><td height="10"></td></tr>
																<tr>
																	<td width="20%"><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php echo ( isset($serumdata['zoonotic_disease']) && $serumdata['zoonotic_disease']==1) ? 'checked' : ''; ?> /> Yes</label></td>
																	<td width="20%"><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php echo ( isset($serumdata['zoonotic_disease']) && $serumdata['zoonotic_disease']==0) ? 'checked' : ''; ?> /> No</label></td>
																	<td width="60%" colspan="3">
																		<label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">Specify which one(s) if known:</label>
																		<input type="text" value="<?php echo isset($serumdata['zoonotic_disease_dec']) ? $serumdata['zoonotic_disease_dec'] : '';?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:32px; padding:0 10px;">
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr><td height="10"></td></tr>
												<tr>
													<td width="100%;">
														<label style="display:block; color:#346a7e; font-size:14px;">Any additional relevant information (e.g., other known triggers of allergy signs)?</label>
														<textarea style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:100px; padding:0 10px;"><?php echo isset($serumdata['additional_information']) ? $serumdata['additional_information'] : '';?></textarea>
													</td>
												</tr>
											</tbody>
										</table>
										<table width="48%" align="right" cellspacing="0" cellpadding="0" border="0">
											<tbody>
												<tr>
													<td width="100%;" colspan="3">
														<table cellspacing="0" cellpadding="0" border="0" width="100%">
															<tbody>
																<tr>
																	<td colspan="5"><label style="display:block; color:#346a7e; font-size:14px;">Has an elimination food trial been performed with a strict elimination diet?</label></td>
																</tr>
																<tr><td height="10"></td></tr>
																<tr>
																	<td width="20%"><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php echo ( isset($serumdata['elimination_diet']) && $serumdata['elimination_diet']==1) ? 'checked' : ''; ?> /> Yes</label></td>
																	<td width="20%"><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php echo ( isset($serumdata['elimination_diet']) && $serumdata['elimination_diet']==2) ? 'checked' : ''; ?> /> No</label></td>
																	<td width="60%" colspan="3">
																		<label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">Specify which one(s) if known:</label>
																		<input type="text" value="<?php echo isset($serumdata['other_elimination']) ? $serumdata['other_elimination'] : '';?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:32px; padding:0 10px;">
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr><td height="10"></td></tr>
												<tr>
													<td width="100%;" colspan="3">
														<table cellspacing="0" cellpadding="0" border="0" width="100%">
															<tbody>
																<tr>
																	<td colspan="5"><label style="display:block; color:#346a7e; font-size:14px;">Is the animal receiving any medication at the moment?</label></td>
																</tr>
																<tr><td height="10"></td></tr>
																<tr>
																	<td width="20%"><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php echo ( isset($serumdata['medication']) && $serumdata['medication']==1) ? 'checked' : ''; ?> /> Yes</label></td>
																	<td width="20%"><label style="display:block; color:#346a7e; font-size:14px;"><input type="radio" style="margin:0 5px 0 0;" <?php echo ( isset($serumdata['medication']) && $serumdata['medication']==0) ? 'checked' : ''; ?> /> No</label></td>
																	<td width="60%" colspan="3">
																		<label style="display:block; color:#346a7e; margin:0 0 5px 0; font-size:14px;">Specify which one(s) if known:</label>
																		<input type="text" value="<?php echo isset($serumdata['medication_desc']) ? $serumdata['medication_desc'] : '';?>" style="background:#ebeff1; border:1px solid #5b8398; outline:none; width:100%; height:32px; padding:0 10px;">
																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr><td height="10"></td></tr>
												<tr>
													<td width="100%;" colspan="3">
														<table cellspacing="0" cellpadding="0" border="0" width="100%">
															<tbody>
																<tr>
																	<fieldset style="width:100%; border:1px solid #426e89; height:140px;">
																		<legend style="color:#426e89;">Internal Use Only</legend>
																	</fieldset>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
											</tbody>
										</table>
										<table width="100%"><tbody><tr><td height="10"></td></tr></tbody></table>
									</td>
								</tr>
							</tbody>
						</table>
						<table width="100%" style="padding:10px 30px; background:#e5f2f5; max-height:50px;">
							<tbody>
								<tr>
									<td valign="middle"><p style="margin:0; color:#426e89; font-size:18px;">For allergy resources visit nextmunelaboratories.co.uk/login</p></td>
									<td valign="bottom"><img src="<?php echo base_url("/assets/images/lock.png"); ?>" alt="Login" /></td>
								</tr>
							</tbody>
						</table>
						<table width="100%" cellpadding="0" cellspacing="0" border="0">
							<tbody>
								<tr>
									<td style="background:#426e89; padding:20px 15px;" align="center">
										<h5 style="color:#ffffff; font-size:30px; font-weight:600; line-height:22px; text-transform:uppercase; margin:0 0 10px 0;">SAMPLE SUBMISSION FORM</h5>
										<p style="color:#d7ecf0; font-size:20px; line-height:22px; text-transform:uppercase; margin:0;">PLEASE SELECT INDIVIDUAL TEST(S) BY TICKING THE APPROPRIATE BOX(ES)</p>
									</td>
								</tr>
							</tbody>
						</table>
						<table width="100%" cellpadding="0" cellspacing="0" border="0">
							<tr><td colspan="2" height="20"></td></tr>
							<tr>
								<td width="30%" valign="top">
									<h5 style="color:#426e89;font-size: 25px; font-weight:600; line-height:22px; text-transform:uppercase;margin: 0 15px 10px 0;text-align: right;">STORAGE ONLY</h5>
								</td>
								<td width="70%" valign="top">
									<table cellpadding="0" cellspacing="0" border="0" style="">
										<tr>
											<td valign="top"><input type="checkbox" style="margin:0 10px 0 0;" /></td>
											<td valign="top"><label style="display:block; color:#1e3743; font-size:14px;">Samples will be held free of charge for 3 months. If you select storage only, please do not tick a test type. Please contact us when you wish to run this sample</label></td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
						<?php if($order_details['species_name'] == 'Dog'){ ?>
						<table width="100%" cellpadding="0" cellspacing="0" border="0">
							<tr><td colspan="2" height="20"></td></tr>
							<tr>
								<td width="20%" valign="top"><img src="<?php echo base_url("/assets/images/dog.png"); ?>" width="270" alt="CANINE TEST" /></td>
								<td width="80%" valign="top">
									<table cellpadding="0" cellspacing="0" border="0" style="padding:23px 0 0 0;">
										<tr>
											<td style="background:#cee8ee; color:#426e89; font-size:32px;" valign="middle">CANINE TESTS</td>
											<td style="line-height:0;" valign="top"><img src="<?php echo base_url("/assets/images/tail1.png"); ?>" height="68" alt="CANINE" /></td>
											<td valign="top"></td>
										</tr>
									</table>
									<table cellpadding="0" cellspacing="0" border="0" style="">
										<tr><td height="30"></td></tr>
										<tr><td colspan="2" style="font-weight:700; color:#426e89; font-size:24px;">NEXTLAB</td></tr>
										<tr><td height="10"></td></tr>
										<tr>
											<td valign="top"><input type="checkbox" style="margin:0 10px 0 0;" /></td>
											<td valign="top"><label style="display:block; color:#346a7e; font-size:14px;">COMPLETE ENVIRONMENTAL & FOOD : Food panel, environmental panel (indoor & outdoor) & Malassezia IgE. Sample required: 2ml serum</label></td>
										</tr>
										<tr><td height="10"></td></tr>
										<tr>
											<td valign="top"><input type="checkbox" style="margin:0 10px 0 0;" /></td>
											<td valign="top"><label style="display:block; color:#346a7e; font-size:14px;">ENVIRONMENTAL: Environmental panel (indoor & outdoor) & Malassezia IgE. Sample required: 1ml serum</label></td>
										</tr>
										<tr><td height="10"></td></tr>
										<tr>
											<td valign="top"><input type="checkbox" style="margin:0 10px 0 0;" /></td>
											<td valign="top"><label style="display:block; color:#346a7e; font-size:14px;">FOOD : Food panel. Sample required: 1ml serum</label></td>
										</tr>
									</table>
									<table cellpadding="0" cellspacing="0" border="0" style="">
										<tr><td height="30"></td></tr>
										<tr><td colspan="2" style="font-weight:700; color:#426e89; font-size:24px;">NEXTLAB SCREENS <small style="color:#333333; font-size:50%;">(positive/negative result only; can be expanded on request)</small></td></tr>
										<tr><td height="10"></td></tr>
										<tr>
											<td valign="top"><input type="checkbox" style="margin:0 10px 0 0;" /></td>
											<td valign="top"><label style="display:block; color:#346a7e; font-size:14px;">ENVIRONMENTAL SCREEN: Sample required: 1ml serum</label></td>
										</tr>
										<tr><td height="10"></td></tr>
										<tr>
											<td valign="top"><input type="checkbox" style="margin:0 10px 0 0;" /></td>
											<td valign="top"><label style="display:block; color:#346a7e; font-size:14px;">FOOD SCREEN: Sample required: 1ml serum</label></td>
										</tr>
										<tr><td height="30"></td></tr>
									</table>
									<table cellpadding="0" cellspacing="0" border="0" style="">
										<tr><td colspan="2" style="font-weight:700; color:#426e89; font-size:24px;">ACUTE PHASE PROTEINS (APPs)</td></tr>
										<tr><td height="10"></td></tr>
										<tr>
											<td valign="top"><input type="checkbox" style="margin:0 10px 0 0;" /></td>
											<td valign="top"><label style="display:block; color:#346a7e; font-size:14px;">C-REACTIVE PROTEIN (CRP) Sample required: 0.5ml serum</label></td>
										</tr>
										<tr><td height="30"></td></tr>
									</table>
								</td>
							</tr>
						</table>
						<?php } ?>
						<?php if($order_details['species_name'] == 'Cat'){ ?>
						<table width="100%" cellpadding="0" cellspacing="0" border="0">
							<tr>
								<td width="20%" valign="top"><img src="<?php echo base_url("/assets/images/cat.png"); ?>" width="270" alt="FELINE TESTS" /></td>
								<td width="80%" valign="top">
									<table cellpadding="0" cellspacing="0" border="0" style="padding:38px 0 0 0;">
										<tr>
											<td style="background:#7dc1c9; color:#ffffff; font-size:32px;" valign="middle">FELINE TESTS</td>
											<td style="line-height:0;" valign="top"><img src="<?php echo base_url("/assets/images/tail2.png"); ?>" height="67" alt="FELINE" /></td>
											<td valign="top"></td>
										</tr>
									</table>
									<table cellpadding="0" cellspacing="0" border="0" style="">
										<tr><td height="30"></td></tr>
										<tr><td colspan="2" style="font-weight:700; color:#426e89; font-size:24px;">NEXTLAB</td></tr>
										<tr><td height="10"></td></tr>
										<tr>
											<td valign="top"><input type="checkbox" style="margin:0 10px 0 0;" /></td>
											<td valign="top"><label style="display:block; color:#346a7e; font-size:14px;">COMPLETE ENVIRONMENTAL & FOOD : Food panel, environmental panel (indoor & outdoor) & 
											Malassezia IgE. Sample required: 2ml serum</label></td>
										</tr>
										<tr><td height="10"></td></tr>
										<tr>
											<td valign="top"><input type="checkbox" style="margin:0 10px 0 0;" /></td>
											<td valign="top"><label style="display:block; color:#346a7e; font-size:14px;">ENVIRONMENTAL: Environmental panel (indoor & outdoor) & Malassezia IgE. Sample required: 1ml serum</label></td>
										</tr>
										<tr><td height="10"></td></tr>
										<tr>
											<td valign="top"><input type="checkbox" style="margin:0 10px 0 0;" /></td>
											<td valign="top"><label style="display:block; color:#346a7e; font-size:14px;">FOOD : Food panel. Sample required: 1ml serum</label></td>
										</tr>
									</table>
									<table cellpadding="0" cellspacing="0" border="0" style="">
										<tr><td height="30"></td></tr>
										<tr><td colspan="2" style="font-weight:700; color:#426e89; font-size:24px;">NEXTLAB SCREENS <small style="color:#333333; font-size:50%;">(positive/negative result only; can be expanded on request)</small></td></tr>
										<tr><td height="10"></td></tr>
										<tr>
											<td valign="top"><input type="checkbox" style="margin:0 10px 0 0;" /></td>
											<td valign="top"><label style="display:block; color:#346a7e; font-size:14px;">ENVIRONMENTAL SCREEN: Sample required: 1ml serum</label></td>
										</tr>
										<tr><td height="10"></td></tr>
										<tr>
											<td valign="top"><input type="checkbox" style="margin:0 10px 0 0;" /></td>
											<td valign="top"><label style="display:block; color:#346a7e; font-size:14px;">FOOD SCREEN: Sample required: 1ml serum</label></td>
										</tr>
										<tr><td height="30"></td></tr>
									</table>
									<table cellpadding="0" cellspacing="0" border="0" style="">
										<tr><td colspan="2" style="font-weight:700; color:#426e89; font-size:24px;">ACUTE PHASE PROTEINS (APPs)</td></tr>
										<tr><td height="10"></td></tr>
										<tr>
											<td valign="top"><input type="checkbox" style="margin:0 10px 0 0;" /></td>
											<td valign="top"><label style="display:block; color:#346a7e; font-size:14px;">α1-ACID GLYCOPROTEIN (AGP): Sample required: 0.5ml serum</label></td>
										</tr>
										<tr><td height="30"></td></tr>
									</table>
								</td>
							</tr>
						</table>
						<?php } ?>
						<?php if($order_details['species_name'] == 'Horse'){ ?>
						<table width="100%" cellpadding="0" cellspacing="0" border="0">
							<tr>
								<td width="20%" valign="top"><img src="<?php echo base_url("/assets/images/horse.png"); ?>" width="270" alt="EQUINE TESTS" /></td>
								<td width="80%" valign="top">
									<table cellpadding="0" cellspacing="0" border="0" style="padding:24px 0 0 0;">
										<tr>
											<td style="background:#b8c6d6; color:#426e89; font-size:32px;" valign="middle">EQUINE TESTS</td>
											<td style="line-height:0;" valign="top"><img src="<?php echo base_url("/assets/images/tail3.png"); ?>" height="68" alt="EQUINE" /></td>
											<td valign="top"></td>
										</tr>
									</table>
									<table cellpadding="0" cellspacing="0" border="0" style="">
										<tr><td height="30"></td></tr>
										<tr><td colspan="2" style="font-weight:700; color:#426e89; font-size:24px;">NEXTLAB</td></tr>
										<tr><td height="10"></td></tr>
										<tr>
											<td valign="top"><input type="checkbox" style="margin:0 10px 0 0;" /></td>
											<td valign="top"><label style="display:block; color:#346a7e; font-size:14px;">COMPLETE ENVIRONMENTAL & FOOD : Food panel, environmental panel (indoor & outdoor) & 
											Malassezia IgE. Sample required: 2ml serum</label></td>
										</tr>
										<tr><td height="10"></td></tr>
										<tr>
											<td valign="top"><input type="checkbox" style="margin:0 10px 0 0;" /></td>
											<td valign="top"><label style="display:block; color:#346a7e; font-size:14px;">ENVIRONMENTAL: Environmental panel (indoor & outdoor) & Malassezia IgE. Sample required: 1ml serum</label></td>
										</tr>
										<tr><td height="10"></td></tr>
										<tr>
											<td valign="top"><input type="checkbox" style="margin:0 10px 0 0;" /></td>
											<td valign="top"><label style="display:block; color:#346a7e; font-size:14px;">FOOD : Food panel. Sample required: 1ml serum</label></td>
										</tr>
									</table>
									<table cellpadding="0" cellspacing="0" border="0" style="">
										<tr><td height="30"></td></tr>
										<tr><td colspan="2" style="font-weight:700; color:#426e89; font-size:24px;">NEXTLAB SCREENS <small style="color:#333333; font-size:50%;">(positive/negative result only; can be expanded on request)</small></td></tr>
										<tr><td height="10"></td></tr>
										<tr>
											<td valign="top"><input type="checkbox" style="margin:0 10px 0 0;" /></td>
											<td valign="top"><label style="display:block; color:#346a7e; font-size:14px;">ENVIRONMENTAL SCREEN: Sample required: 1ml serum</label></td>
										</tr>
										<tr><td height="10"></td></tr>
										<tr>
											<td valign="top"><input type="checkbox" style="margin:0 10px 0 0;" /></td>
											<td valign="top"><label style="display:block; color:#346a7e; font-size:14px;">FOOD SCREEN: Sample required: 1ml serum</label></td>
										</tr>
										<tr><td height="30"></td></tr>
									</table>
									<table cellpadding="0" cellspacing="0" border="0" style="">
										<tr><td colspan="2" style="font-weight:700; color:#426e89; font-size:24px;">ACUTE PHASE PROTEINS (APPs)</td></tr>
										<tr><td height="10"></td></tr>
										<tr>
											<td valign="top"><input type="checkbox" style="margin:0 10px 0 0;" /></td>
											<td valign="top"><label style="display:block; color:#346a7e; font-size:14px;">ENVIRONMENTAL & INSECT SCREEN: Sample required: 2ml serum</label></td>
										</tr>
										<tr><td height="30"></td></tr>
									</table>
								</td>
							</tr>
						</table>
						<?php } ?>
						<table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding:0 15px;">
							<tr>
								<td align="left">
									<p style="color:#333333; font-size:13px; line-height:20px;">Samples submitted are subject to Nextmune Laboratories’ terms & conditions of business (www.nextmunelaboratories.co.uk/terms-of-business)</p>
									<p style="color:#333333; font-size:13px; line-height:20px;">We may store and use any surplus serum for quality control, research and development purposes.</br>
									If you do not wish Nextmune Laboratories to utilise this sample, please tick here</p>
								</td>
							</tr>
						</table>
						<table width="100%" cellpadding="0" cellspacing="0" border="0">
							<tr>
								<td style="background:#426e89; padding:0 15px;" align="center">
									<p style="color:#ffffff; font-size:15px; line-height:22px;">Nextmune Laboratories Limited, Unit 651, Street 5, Thorp Arch Trading Estate, Wetherby, UK, LS23 7FZ<br> T – 0800 3 047 047 E – <a style="color:#ffffff;" href="mailto:vetorders.uk@nextmune.com">vetorders.uk@nextmune.com</a></p>
								</td>
							</tr>
						</table>
						<table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding:10px 30px;">
							<tr>
								<td style="font-size:13px; font-weight:600; color:#333333;">&copy; 2022 Nextmune Laboratories Limited</td>
								<td style="font-size:12px; color:#333333;" align="right">NM035_06_22</td>
							</tr>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
	</body>
</html>